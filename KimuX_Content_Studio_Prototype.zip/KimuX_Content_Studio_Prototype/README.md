# KimuX Content Studio — team setup guide

This folder contains the local showcase for the **AI-assisted marketing content creation module**. The site runs on each teammate’s Windows computer. This private repository includes the team’s demo account database so the same demo admin account can be used on each clone. The prototype binds to the computer running it; it is not a shared hosted service.

## What you need

- Windows 10 or 11
- Python 3.10 or newer ([download for Windows](https://www.python.org/downloads/windows/))
- A modern browser such as Chrome or Edge
- The project folder on your computer, obtained from the team’s GitHub repository or a ZIP shared by a teammate

The basic Content Studio uses Python’s built-in libraries. It does not need extra Python packages, a database installation, or an internet connection after you have the project folder. Internet is needed to download the folder and is optional for the offline assistant setup below.

## Get the project folder

### Option A — GitHub Desktop

1. Install and open GitHub Desktop, then sign in to GitHub.
2. Choose **File → Clone repository**.
3. Select the Team Adventurers KimuX project and choose a location on your computer.
4. After it finishes, open the cloned folder. The correct folder contains `server.py`, `index.html`, `app.js`, and this `README.md` at its top level.
5. To get later updates, use **Fetch origin** and then **Pull origin** in GitHub Desktop.

### Option B — Download a ZIP

1. On the project’s GitHub page, choose **Code → Download ZIP**.
2. Extract the ZIP to a normal folder such as `Documents\KimuX_Content_Studio_Prototype`.
3. Open that extracted project folder. Do not run the app from inside the ZIP preview.

## Start the Content Studio

1. Open the project folder in File Explorer.
2. Click the folder address bar, type `powershell`, and press **Enter**. A PowerShell window opens in that folder.
3. Check Python is available:

   ```powershell
   py -3 --version
   ```

   The version should be 3.10 or newer. If Windows says `py` is not recognized, install Python from the link above, close PowerShell, reopen it, and try again. You can use `python` in place of `py -3` in the commands below if that is the Python command available on your computer.

4. The repository includes the team demo account database. If the maintainer has shared the demo admin sign-in with you, keep the supplied database and use those credentials. To create a separate local account instead, first delete `instance\accounts.sqlite3`, then run:

   ```powershell
   py -3 server.py --create-admin
   ```

   Enter your display name, email, and password when prompted. The demo accepts passwords from 4 characters, but choose a stronger **demo-only** password and do not reuse a personal or work password. This creates an active admin account just for this computer’s copy of the prototype.

5. Start the website and account service:

   ```powershell
   py -3 server.py
   ```

   Leave this PowerShell window open while using the site.

6. In your browser on the same computer, open:

   **http://127.0.0.1:8766/**

7. Sign in with the existing demo admin credentials shared privately by the maintainer, or with the credentials you created in step 4. The admin account is active immediately, so it does not need an activation email.

8. When finished, return to the PowerShell window and press **Ctrl+C** to stop the local server.

## Accounts for teammates

The private repository includes `instance\accounts.sqlite3` so the team can sign in using the existing demo admin account. It stores account records, password hashes, and campaign history; the app can add session and activation-token records as teammates use it. The uploaded copy has no active sessions or activation links. Repository access also grants access to this database. It must contain fictional demo data only. The maintainer should share the demo sign-in details separately with intended teammates; do not put passwords in this README or commit them elsewhere.

Each clone runs its own local copy of the database. Because the site listens only on `127.0.0.1`, a teammate’s copy is not a shared server. To start with an empty local account database, delete `instance\accounts.sqlite3` and follow step 4 to create a new admin. The business and market knowledge database under `offline_assistant\data\` is a separate project data file and is included.

Regular sign-ups create User accounts. In demo mode, registration displays an activation link on screen and prints it in the server window; it does **not** send email. The first local admin bypasses this activation step. An admin can manage activated accounts from the account administration area.

## Start local AI generation and the Studio Guide

The page and account service can open without a model, but campaign generation, copy improvement, AI critique, and Studio Guide answers require Ollama and the local model. Complete the one-time setup in [`offline_assistant/README.md`](offline_assistant/README.md). From the project folder, open a second PowerShell window and run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\offline_assistant\start_offline_assistant.ps1
```

If the model is missing, run `ollama pull qwen3.5:0.8b` once while connected to the internet, then start the assistant again. Campaign drafts and reviews use this smaller model for a quicker local demo. The Studio Guide uses `qwen3.5:4b` when it is installed and falls back to `qwen3.5:0.8b` otherwise; install it optionally with `ollama pull qwen3.5:4b`. Startup warms each installed model. Draft creation and the optional AI review are separate actions so a routine draft does not wait for two model calls. Leave both the Content Studio and assistant windows open while demonstrating the site. Each teammate must install models on their own computer. AI requests run on that computer; there is no cloud AI fallback.

## Troubleshooting

- **`py` is not recognized:** Install Python 3.10 or newer, reopen PowerShell, and try the version check again. You may use `python` instead of `py -3` if available.
- **Port 8766 is already in use:** Find the earlier KimuX server PowerShell window and stop it with **Ctrl+C**, then run `py -3 server.py` again.
- **The browser cannot connect:** Confirm the server window is still open and says the site is running at `http://127.0.0.1:8766/`. Use that exact address on the same computer.
- **Admin creation says an admin already exists:** This computer’s local account database already has an admin. Sign in with that account. If it belongs to another teammate and this is a fresh demo copy, do not overwrite or share the database; ask the project maintainer to help set up a clean local copy.
- **A regular user cannot sign in:** The user account must first be activated using the link shown after registration or printed in the server window.

## What the prototype demonstrates

- Five fictional sample businesses: coffee, automotive, fashion, design, and food.
- A compact account dashboard with saved campaign and version counts, latest activity, local model availability, and an average advisory review score for saved versions.
- Local AI generation tailored to the brief's audience, objective, tone, optional brand guidance, language, and Facebook, Instagram, LinkedIn, or WhatsApp channel.
- Local AI improvement of existing marketing copy, AI-guided variants, marketer feedback revisions, and an editable headline, caption, and hashtag list.
- A six-part AI advisory review: relevance, clarity, audience fit, tone fit, platform fit, and factual support. The total is a normalized 0–100 summary of 0–5 ratings; it is not an objective measurement, legal check, or approval.
- Account-owned SQLite campaign history. Each save creates a version with its brief, copy, reviewer note, quality review, and human-review state.
- Editable SVG campaign artwork composed from the brief; it is not a live image-generation service.
- A local SQLite + Ollama Studio Guide that retrieves from the separate business and market knowledge database.
- Local demo accounts with User and Admin roles.

The language model uses the selected brief and verified facts, plus an explicitly fictional writing-pattern example. Replace sample examples with KimuX marketer-approved examples and add approved brand rules before a live release. The prototype is not connected to KimuX identity, email delivery, social publishing, or a hosted service. The sample businesses and their details are fictional. Review all generated copy before use.

## Coffee market data

The Studio Guide retrieves curated facts from SQLite; it does not learn current prices by training on a raw internet download. The starter database now includes USDA coffee import and consumption estimates for the United States and Canada and Rwanda's 2025 national export and farm-gate figures. These are dated national commodity indicators, not local retail prices or demand for Lakeview Coffee Co. Uganda Coffee Development Authority, U.S. Bureau of Labor Statistics, Statistics Canada and International Coffee Organization price-data sources are catalogued. Import a numeric price only with its grade/product form, price stage, geography, currency, unit, date, source and caveat. City-level consumer prices, local competitors and brand-specific demand are not yet in the database. See [`offline_assistant/README.md`](offline_assistant/README.md) for the source map and scope.

## CAT 2 demonstration tasks

Capture the actual generated copy, brief settings, AI review, and screenshots for both tasks. Record the model name and note when it was run.

1. **Audience adaptation:** Use a solar lighting kit with only owner-confirmed facts. Generate for Ugandan households, then change the audience to retail distributors. Compare the buyer need, wording, and call to action. The draft should adapt without inventing price, stock, warranty, or performance claims.
2. **Platform adaptation:** Keep the product, facts, audience, and objective the same; generate once for Instagram and once for LinkedIn. Compare format, tone, length, and call to action. The messages should reflect each platform while preserving supported claims.

Treat the scores as advisory model feedback. Report the actual outputs and limitations rather than claiming the model passed a test based on a high score alone.

## Team responsibilities

- **Ivan:** coordinate requirements, acceptance criteria, architecture decisions, and the final demonstration.
- **Kamal:** maintain the local AI endpoints, prompts, and integration with Ollama.
- **Robert:** maintain the responsive campaign workflow and editable content screens.
- **Monica:** maintain the campaign and version-history database, account ownership, and data quality boundaries.
- **Sydney:** define the marketing review rubric, run the two demonstration tasks, and capture evidence and limitations.

## Security and demo limits

Use fictional/demo credentials only. This is a local showcase, not production account security. The private repository intentionally contains the demo account database; do not make this repository public or include real account details, session data, or campaign content. Share the demo password separately with intended teammates. Password length defaults to 4 characters for classroom demonstrations; use at least 12 characters and add appropriate protections before any real deployment. Keep `.env` files and database backups private. The prototype is bound to loopback and does not expose itself to other computers.

## Design direction

The interface uses a dark workspace, compact navigation, teal actions, and restrained color accents based on the supplied KimuX reference. Confirm official brand colors, typography, and design standards with KimuX before a connected release.
