$ErrorActionPreference = "Stop"

$modelName = if ($env:KIMUX_LOCAL_MODEL) { $env:KIMUX_LOCAL_MODEL } else { "qwen3.5:0.8b" }
Write-Host "This one-time setup downloads the Ollama Windows runtime and the $modelName model." -ForegroundColor Cyan
Write-Host "After setup, the assistant can answer locally without an internet connection."
$confirmation = Read-Host "Continue with the downloads now? Type Y to continue"
if ($confirmation -notin @("Y", "y")) { Write-Host "Setup cancelled."; exit 0 }

$ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
if (-not $ollamaCommand) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "Install Ollama from https://ollama.com/download/windows, reopen PowerShell, and run this setup again."
  }
  winget install --id Ollama.Ollama --exact --source winget --silent --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) { throw "Ollama installation did not complete. Check the installer output and retry." }
}

$ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
$candidatePaths = @("$env:LOCALAPPDATA\Programs\Ollama\ollama.exe", "$env:ProgramFiles\Ollama\ollama.exe")
$ollamaExe = if ($ollamaCommand) { $ollamaCommand.Source } else { $candidatePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1 }
if (-not $ollamaExe) { throw "Ollama installed, but PowerShell cannot find ollama.exe. Reopen PowerShell and run this script again." }

Write-Host "Downloading $modelName. Keep this window open until the download completes." -ForegroundColor Cyan
& $ollamaExe pull $modelName
if ($LASTEXITCODE -ne 0) { throw "The model download did not complete. Run this setup again when the connection is available." }

Write-Host "Offline model is ready. Start it with start_offline_assistant.ps1." -ForegroundColor Green
