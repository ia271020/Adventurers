from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT.parent
OUT = ROOT / "docs" / "KimuX_CAT2_and_Offline_Assistant_Guide_Updated.docx"
EVIDENCE = PROJECT / "cat2-evidence"

TEAL = "0B302E"
GREEN = "00A979"
GOLD = "D9AD55"
INK = "263532"
MUTED = "60716B"
PALE = "EEF5F1"
PALE_GOLD = "FBF4E4"
GRID = "D8E3DD"
WHITE = "FFFFFF"


def shade(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=90, start=105, bottom=90, end=105) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    margins = tc_pr.first_child_found_in("w:tcMar")
    if margins is None:
        margins = OxmlElement("w:tcMar")
        tc_pr.append(margins)
    for m, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = margins.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            margins.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_cell_border(cell, color=GRID, size="5") -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), size)
        element.set(qn("w:color"), color)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    repeat = OxmlElement("w:tblHeader")
    repeat.set(qn("w:val"), "true")
    tr_pr.append(repeat)


def no_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    element = OxmlElement("w:cantSplit")
    tr_pr.append(element)


def set_run_font(run, size=None, bold=None, color=INK, name="Aptos") -> None:
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    run.font.color.rgb = RGBColor.from_string(color)


def set_cell_text(cell, text, bold=False, color=INK, size=9.2) -> None:
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.05
    r = p.add_run(text)
    set_run_font(r, size=size, bold=bold, color=color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
    set_cell_margins(cell)


def add_table(doc, headers, rows, widths=None, font_size=9.0):
    table = doc.add_table(rows=1, cols=len(headers))
    table.autofit = False
    table.style = "Table Grid"
    header = table.rows[0]
    set_repeat_table_header(header)
    no_split(header)
    for i, title in enumerate(headers):
        set_cell_text(header.cells[i], title, bold=True, color=WHITE, size=9.0)
        shade(header.cells[i], TEAL)
        set_cell_border(header.cells[i], color=TEAL)
    for row_data in rows:
        row = table.add_row()
        no_split(row)
        for i, value in enumerate(row_data):
            set_cell_text(row.cells[i], str(value), size=font_size)
            if len(table.rows) % 2 == 0:
                shade(row.cells[i], "F7FAF8")
            set_cell_border(row.cells[i])
    if widths:
        for row in table.rows:
            for i, width in enumerate(widths):
                row.cells[i].width = Inches(width)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return table


def add_hyperlink(paragraph, text, url, color=GREEN, size=8.3):
    part = paragraph.part
    rel_id = part.relate_to(
        url,
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",
        is_external=True,
    )
    hyperlink = OxmlElement("w:hyperlink")
    hyperlink.set(qn("r:id"), rel_id)
    run = OxmlElement("w:r")
    r_pr = OxmlElement("w:rPr")
    color_node = OxmlElement("w:color")
    color_node.set(qn("w:val"), color)
    r_pr.append(color_node)
    size_node = OxmlElement("w:sz")
    size_node.set(qn("w:val"), str(int(size * 2)))
    r_pr.append(size_node)
    run.append(r_pr)
    text_node = OxmlElement("w:t")
    text_node.text = text
    run.append(text_node)
    hyperlink.append(run)
    paragraph._p.append(hyperlink)


def body(doc, text, bold_lead=None, size=10.1, after=5):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.line_spacing = 1.12
    if bold_lead and text.startswith(bold_lead):
        r1 = p.add_run(bold_lead)
        set_run_font(r1, size=size, bold=True, color=TEAL)
        r2 = p.add_run(text[len(bold_lead):])
        set_run_font(r2, size=size, color=INK)
    else:
        r = p.add_run(text)
        set_run_font(r, size=size, color=INK)
    return p


def bullet(doc, text, level=0, size=9.8):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(2.5)
    p.paragraph_format.line_spacing = 1.05
    r = p.add_run(text)
    set_run_font(r, size=size, color=INK)
    return p


def numbered(doc, number, title, text):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Inches(0.05)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_together = True
    r = p.add_run(f"{number}  {title}  ")
    set_run_font(r, size=10.1, bold=True, color=TEAL)
    r2 = p.add_run(text)
    set_run_font(r2, size=9.8, color=INK)


def callout(doc, title, text, fill=PALE):
    table = doc.add_table(rows=1, cols=1)
    table.autofit = False
    table.columns[0].width = Inches(6.85)
    cell = table.cell(0, 0)
    shade(cell, fill)
    set_cell_border(cell, color=GREEN if fill == PALE else GOLD, size="8")
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run(title)
    set_run_font(r, size=10.1, bold=True, color=TEAL)
    p2 = cell.add_paragraph()
    p2.paragraph_format.space_after = Pt(0)
    p2.paragraph_format.line_spacing = 1.08
    r2 = p2.add_run(text)
    set_run_font(r2, size=9.4, color=INK)
    set_cell_margins(cell, top=130, start=160, bottom=130, end=160)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def heading(doc, text, level=1):
    p = doc.add_paragraph(style=f"Heading {level}")
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(7 if level == 1 else 5)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    set_run_font(r, size=17 if level == 1 else 11.5, bold=True, color=TEAL if level == 1 else GREEN)
    return p


def page_label(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text.upper())
    set_run_font(r, size=8, bold=True, color=GOLD)


def add_page_break(doc):
    doc.add_page_break()


def setup_styles(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.27)
    section.page_height = Inches(11.69)
    section.top_margin = Inches(0.64)
    section.bottom_margin = Inches(0.62)
    section.left_margin = Inches(0.72)
    section.right_margin = Inches(0.72)
    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(10.1)
    normal.font.color.rgb = RGBColor.from_string(INK)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.12
    for style_name, size in (("Title", 27), ("Subtitle", 13), ("Heading 1", 17), ("Heading 2", 11.5)):
        style = doc.styles[style_name]
        style.font.name = "Aptos Display" if style_name in ("Title", "Heading 1") else "Aptos"
        style.font.size = Pt(size)
        style.font.bold = style_name != "Subtitle"
        style.font.color.rgb = RGBColor.from_string("000000" if style_name == "Title" else TEAL)
    header = section.header.paragraphs[0]
    header.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    header.paragraph_format.space_after = Pt(0)
    rh = header.add_run("KIMUX  |  TEAM ADVENTURERS")
    set_run_font(rh, size=8, bold=True, color=TEAL)
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.paragraph_format.space_before = Pt(0)
    rf = footer.add_run("CAT 2 REPORT AND OFFLINE ASSISTANT GUIDE  |  21 NOVEMBER 2026")
    set_run_font(rf, size=7.5, color=MUTED)


def add_sources_line(doc, items):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    for i, (label, url) in enumerate(items):
        if i:
            sep = p.add_run("   ·   ")
            set_run_font(sep, size=8.0, color=MUTED)
        add_hyperlink(p, label, url, size=8.0)


def create_document():
    doc = Document()
    setup_styles(doc)

    # Page 1: short executive response to CAT 2 before the system description.
    page_label(doc, "PART 1  CAT 2 QUESTIONS AND ANSWERS")
    title = doc.add_paragraph(style="Title")
    title.paragraph_format.space_after = Pt(3)
    title.paragraph_format.keep_with_next = True
    title_run = title.add_run("KimuX AI Marketing Content Creation CAT 2 Report")
    set_run_font(title_run, size=25, bold=True, color="000000", name="Aptos Display")
    subtitle = doc.add_paragraph()
    subtitle.paragraph_format.space_after = Pt(9)
    sr = subtitle.add_run("Team Adventurers  |  Prototype findings and offline assistant design")
    set_run_font(sr, size=11.2, color=GREEN)
    body(doc, "Assigned area: AI-assisted marketing content creation. This report answers the CAT 2 prompts first, then documents the local prototype and the offline business assistant being prepared.", size=10.1, after=7)
    callout(doc, "CAT 2 answer in brief", "The public KimuX page identifies AI-assisted marketing content creation but does not explain the marketer's brief-to-output workflow or the quality controls shown in our proposed prototype. We propose a guided brief, client-specific copy and editable campaign visual, claim checks, expert examples, and human approval. Two realistic tasks were completed against the local prototype. The underlying live KimuX feature was not verified.")
    heading(doc, "CAT 2 criteria covered", 2)
    add_table(doc, ["Assessment prompt", "Our response in this report", "Pts"], [
        ("Identify two user-facing weaknesses", "Public description and workflow transparency; claim and review safeguards", "4"),
        ("Describe one practical improvement", "Guided, evidence-led content workflow for local and export marketing", "3"),
        ("Develop a prototype and explain its use", "Five demo sectors, client brief, tailored SVG, review and export steps", "7"),
        ("Test two realistic user tasks", "Coffee retail Instagram and automotive export LinkedIn", "4"),
        ("Show individual contribution", "Five role areas and evidence each member should attach", "2"),
    ], widths=[2.1, 4.25, 0.5], font_size=8.5)
    callout(doc, "Evidence boundary", "The findings about missing workflow detail refer to the public KimuX page. They do not prove that a private or unreleased KimuX feature lacks these capabilities. The prototype and its sample business facts are illustrative.", fill=PALE_GOLD)

    # Page 2: CAT 2 problem identification.
    add_page_break(doc)
    page_label(doc, "CAT 2 QUESTION 1  PROBLEM IDENTIFICATION")
    heading(doc, "Two weaknesses that affect users")
    body(doc, "KimuX publicly describes AI-assisted marketing content creation and a universal marketing hub with multi-channel campaigns, product showcases, automated distribution, engagement analytics, and AI-driven branding and storytelling. The public description does not show a marketer how to move from a business brief to an approved piece of content.")
    add_table(doc, ["Weakness in the public description", "Evidence and user impact"], [
        ("The creation workflow is unclear", "The KimuX page names the AI content feature and marketing capabilities but does not show the brief fields, an example output, or how a user selects audience, market, channel and objective. A new marketer may not know what to enter or what the feature will produce."),
        ("Quality and review controls are not explained", "The page refers to AI-driven branding and storytelling but does not explain how brand rules, verified product facts, unsupported claims, marketer feedback or approval are handled. Users cannot assess how to keep drafts accurate and on-brand from the public description."),
    ], widths=[2.0, 4.85], font_size=9.0)
    heading(doc, "Evidence and scope", 2)
    body(doc, "These are defensible gaps in the information published for users. We could not verify the private KimuX marketing generator or inspect its internal workflow through the public page. We therefore treat the two findings as transparency and onboarding problems, not as proof that the production system lacks these controls.")
    add_sources_line(doc, [("KimuX public page", "https://kimuntupower.com/kimu-x/")])
    callout(doc, "Why this matters", "When users cannot see what information to provide, what they will receive, or who checks the draft, they may create generic content, omit important context, or publish a claim that the business has not proved.")

    # Page 3: CAT 2 improvement.
    add_page_break(doc)
    page_label(doc, "CAT 2 QUESTION 2  PROPOSED IMPROVEMENT")
    heading(doc, "A guided campaign brief with visible review")
    body(doc, "Add a focused content-creation path that asks for the facts a marketer needs, creates channel-specific draft options and a brief-tailored visual, then makes claim review and human approval part of the same flow.")
    add_table(doc, ["Who benefits", "How the improvement helps"], [
        ("Small and growing businesses", "A guided brief reduces guesswork and turns verified product details into a usable first draft."),
        ("Exporters and distributors", "A local-versus-export view makes destination, buyer type and market context explicit."),
        ("Marketing creators", "Approved examples and brand guidance give the assistant a consistent pattern to follow and critique."),
        ("Business owners and reviewers", "A fact trail and human approval step keep responsibility for claims visible."),
    ], widths=[1.9, 4.95], font_size=9.0)
    heading(doc, "How the assistant should improve drafts", 2)
    numbered(doc, 1, "Curated creator examples", "Store approved marketing examples by sector, audience, market, channel and goal. Use them as references when generating or critiquing content.")
    numbered(doc, 2, "Brand rules and confirmed facts", "Retrieve the business's approved voice, visual rules, product facts and proof. Ask for missing facts instead of inventing them.")
    numbered(doc, 3, "Iterative critique", "Let the marketer request a shorter, warmer or more direct version. Compare each revision with the brief and flag claims that need evidence.")
    numbered(doc, 4, "Human approval", "A named marketer reviews the wording and visual before the business uses or publishes it.")
    callout(doc, "Training and content quality", "For this prototype, 'training the assistant with great marketers' means curating expert examples and brand guidance, retrieving them at answer time, and improving the workflow through human feedback and evaluation. It does not mean training a foundation model from scratch.", fill=PALE_GOLD)

    # Page 4: CAT 2 prototype and how to use it.
    add_page_break(doc)
    page_label(doc, "CAT 2 QUESTION 3  PROTOTYPE AND PRACTICAL EXAMPLE")
    heading(doc, "The local prototype workflow")
    numbered(doc, 1, "Choose a demo business", "Select coffee, automotive, fashion, design services or food to load an example brief.")
    numbered(doc, 2, "Complete the brief", "Review the business, product or service, verified facts, audience, market, channel, goal, tone and call to action. Replace illustrative values with owner-approved facts for a real business.")
    numbered(doc, 3, "Create and tailor", "Generate a draft and an editable SVG visual from the current brief. Choose a visual mood and download the SVG for further editing.")
    numbered(doc, 4, "Review and refine", "Inspect the fact trail, adjust the message, add marketer feedback and check for claims that need proof. A person remains responsible for approval.")
    numbered(doc, 5, "Export", "Copy or export the draft text and download the campaign visual. Publishing to KimuX or a social platform is not connected.")
    heading(doc, "The five illustrative demo sectors", 2)
    add_table(doc, ["Sector", "Sample business", "Example brief focus"], [
        ("Coffee", "Lakeview Coffee Co.", "Origin, roast, pack size and local or export audience"),
        ("Automotive", "Northstar Auto", "Vehicle specifications, viewing request and export buyer"),
        ("Fashion", "Atelier Nia", "Material, sizes, style and shopper or boutique buyer"),
        ("Design services", "Form & Field Studio", "Package deliverables, client outcome and enquiry"),
        ("Food service", "Malaika Kitchen", "Ingredients, preparation, availability and allergen"),
    ], widths=[1.25, 1.9, 3.95], font_size=8.6)
    callout(doc, "Practical example", "For a local coffee Instagram post, the marketer enters the Kampala audience, Arabica product facts, warm voice and call to action. The prototype writes a draft and assembles an editable visual from those inputs. The marketer confirms every fact before use.")

    # Page 5: CAT 2 task tests.
    add_page_break(doc)
    page_label(doc, "CAT 2 QUESTION 4  TASK TESTING AND RESULTS")
    heading(doc, "Results from two realistic tasks")
    body(doc, "We completed the two user tasks against the local browser prototype. They exercised brief entry, tailored outputs, market context, visual export and claim review. They do not test the live KimuX feature or a connected AI model.")
    add_table(doc, ["Task", "What we entered", "Observed result"], [
        ("Coffee retail Instagram", "Kahawa Collective in Kampala; Hill Arabica; confirmed product facts; local coffee audience; warm and organic mood; 'Order a fresh pack' action.", "The draft and SVG reflected the business, product, market, audience, channel and selected mood. The visual could be downloaded as an SVG."),
        ("Automotive export LinkedIn", "Northstar Auto; 2021 Cityline compact SUV; regional fleet buyers and resellers; Kigali destination; clean and direct mood; 'Book a viewing' action.", "The visual reflected the product and export audience. When we added an unsupported 'best in Kigali' claim, the checker flagged it for evidence or removal."),
    ], widths=[1.35, 2.75, 3.0], font_size=8.45)
    heading(doc, "What we learned", 2)
    bullet(doc, "The brief can shape a business-specific visual instead of selecting a fixed sector illustration.")
    bullet(doc, "A simple claim check can surface an obvious unsupported superlative, but it does not prove every other statement is accurate.")
    bullet(doc, "Market and export questions need a confirmed destination and reliable country-level sources.")
    heading(doc, "Limits on these results", 2)
    body(doc, "The profiles, products and outputs are illustrative; the product details have not been verified with real businesses. The text generator and chatbot in the original showcase are deterministic simulations. The new SQLite knowledge database and local model connection are separate implementation work; the model weights are not yet installed. No statistical quality score or live-KimuX comparison was claimed.")
    # Evidence images are compact so the task outcomes remain visually verifiable.
    evidence_table = doc.add_table(rows=2, cols=2)
    evidence_table.autofit = False
    for row in evidence_table.rows:
        for cell in row.cells:
            cell.width = Inches(3.32)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell, top=50, start=70, bottom=50, end=70)
            set_cell_border(cell)
    image_specs = [
        (EVIDENCE / "task-1-coffee-local.png", "Task 1  Coffee local Instagram"),
        (EVIDENCE / "task-2-auto-export.png", "Task 2  Automotive export and claim warning"),
    ]
    for col, (path, caption) in enumerate(image_specs):
        if path.exists():
            paragraph = evidence_table.cell(0, col).paragraphs[0]
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            paragraph.add_run().add_picture(str(path), width=Inches(3.18))
        set_cell_text(evidence_table.cell(1, col), caption, bold=True, color=TEAL, size=8.2)

    # Page 6: CAT 2 contribution and evidence.
    add_page_break(doc)
    page_label(doc, "CAT 2 QUESTION 5  INDIVIDUAL CONTRIBUTION")
    heading(doc, "Team Adventurers project role assignments")
    body(doc, "Use this ownership split for the next implementation and demo pass. Each member should attach a concrete artifact for their own work, such as requirements notes, source changes, a schema, a screen or a test record.")
    add_table(doc, ["Member", "Workstream", "Assigned work and evidence"], [
        ("Ivan", "Project lead and requirements", "Freeze scope and acceptance criteria; coordinate KimuX architecture and email-provider decisions. Deliver: requirements map, decision log and demo plan."),
        ("Kamal", "Backend and AI", "Own Python account/API service, sessions, activation and role enforcement; continue Ollama and retrieval integration. Deliver: API flow, security notes and model status."),
        ("Robert", "Frontend", "Own sign-in, registration, activation and admin screens; maintain the brief, draft and review workflow. Deliver: responsive UI changes and screenshots."),
        ("Monica", "Database and data quality", "Own separate account and knowledge SQLite schemas, source records, business facts and account-data boundaries. Deliver: schema/data dictionary and reviewed seed data."),
        ("Sydney", "QA and marketing evaluation", "Review user/admin journeys and run the coffee and automotive tasks; assess copy, claims and accessibility. Deliver: results, issue list and evidence screenshots."),
    ], widths=[0.95, 1.8, 4.35], font_size=8.4)
    callout(doc, "Contribution accuracy", "These are assigned owners and deliverables, not proof that every task is complete. Each person must record only work they personally did and attach matching evidence before submission.", fill=PALE_GOLD)
    heading(doc, "Individual submission checklist", 2)
    bullet(doc, "Group name: Team Adventurers.")
    bullet(doc, "Assigned area: AI-assisted marketing content creation.")
    bullet(doc, "Attach the group improvement, findings and two task results.")
    bullet(doc, "Describe your own contribution and include evidence from your actual work.")

    # Page 7: system built and offline architecture.
    add_page_break(doc)
    page_label(doc, "PART 2  THE SYSTEM WE HAVE MADE")
    heading(doc, "Current prototype and offline assistant")
    body(doc, "The Content Studio is a local front-end prototype served by a Python web application. We have also created a source-aware SQLite knowledge base and prepared a local assistant API that connects the browser to an Ollama model on the same computer. The runtime and model weights must finish downloading before the assistant can answer with a language model.")
    body(doc, "The account layer adds local sign-up and sign-in, email-activation tokens, per-account roles and an admin user manager. Public registration starts as User; the first Administrator is created from PowerShell. For the local demo, passwords may be four characters and should be fictional; no SMTP is configured, so activation links are shown locally. Drafts still use account-scoped browser storage, not a server campaign database.", size=9.1, after=5)
    body(doc, "The seed database currently holds five fictional businesses, eleven market profiles, twenty-eight market facts and eleven source records.", bold_lead="The seed database currently holds", size=9.7, after=6)
    flow = add_table(doc, ["1  Brief", "2  Local API", "3  Knowledge", "4  Local model"], [[
        "Python serves HTML, CSS, JavaScript and the account API at 127.0.0.1:8766",
        "Python endpoint at 127.0.0.1:8767 receives the question, selected business and market",
        "SQLite retrieves business facts, market notes and source records",
        "Ollama serves Qwen 3.5 4B locally at 127.0.0.1:11434 and returns a grounded answer",
    ]], widths=[1.72, 1.72, 1.72, 1.72], font_size=8.1)
    for cell in flow.rows[1].cells:
        shade(cell, PALE)
    heading(doc, "Why we use database retrieval", 2)
    body(doc, "The language model already knows how to write and interpret questions. SQLite supplies the business and market facts for each answer. This approach is easier to update than fine-tuning model weights whenever a price, product, source or brand rule changes. It is a local retrieval-augmented assistant, not a foundation model trained from scratch.")
    add_table(doc, ["Knowledge label", "Meaning in this prototype"], [
        ("Official source", "A market statement linked to a public authority and a checked date."),
        ("Illustrative demo", "A fictional business or product detail used to demonstrate the interface."),
        ("Owner confirmation needed", "A field the real business must confirm before a marketer can publish it."),
        ("Guidance", "A recommended workflow or safety rule, not a market statistic or law."),
    ], widths=[1.65, 5.2], font_size=8.8)
    callout(doc, "Local privacy boundary", "The assistant API uses local SQLite and Ollama; it does not need a ChatGPT login or cloud AI key. Content Studio accounts are a separate local service. Runtime and model downloads need internet once; generation can then run locally.")

    # Page 8: markets and references.
    add_page_break(doc)
    page_label(doc, "SYSTEM DATA  MARKET KNOWLEDGE")
    heading(doc, "Markets included in the starter knowledge pack")
    body(doc, "The assistant treats the United States as the North American market requested and distinguishes it from Canada. It treats East Africa as country-specific markets, not a single country.")
    add_table(doc, ["Coverage", "Facts currently stored", "How to use them safely"], [
        ("EAC region", "Eight Partner States; English, Kiswahili and French at EAC institutional level; population 331.1 million in 2023; GDP US$356 billion in 2024.", "Regional context only. Ask for the country, city, audience language and currency. These totals are not a client's addressable market."),
        ("United States", "Population estimate 341,784,857 on July 1, 2025; retail e-commerce 17.9% of retail sales in Q3 2026; FTC advertising guidance.", "Ask for state, city, product category and evidence for claims. Broad retail data is not proof of demand for a specific brand."),
        ("Canada", "Population estimate 41,798,407 on July 1, 2026; 2024 retail e-commerce revenue C$73.7 billion, up 9%; English and French federal languages; Competition Bureau guidance.", "Ask for province, city and language. National statistics and federal guidance do not answer every local or product-specific question."),
    ], widths=[1.15, 3.25, 2.45], font_size=8.2)
    heading(doc, "Internet use in 2024", 2)
    body(doc, "World Bank/ITU country indicator, percent of population: Uganda 8.95; Kenya 34.98; Rwanda 31.70; Tanzania 31.16; Burundi 8.60; Democratic Republic of the Congo 19.67; Somalia 27.94; United States 94.69; Canada 94.35. No 2024 value was returned for South Sudan in the source query. These national measures do not estimate reach in a city or the number of likely buyers.", size=9.0, after=5)
    heading(doc, "Public sources checked for this database", 2)
    add_sources_line(doc, [("KimuX public page", "https://kimuntupower.com/kimu-x/"), ("EAC Partner States", "https://www.eac.int/eac-partner-states"), ("EAC facts", "https://www.eac.int/eac-quick-facts")])
    add_sources_line(doc, [("World Bank and ITU internet use", "https://data.worldbank.org/indicator/IT.NET.USER.ZS"), ("U.S. Census e-commerce", "https://www.census.gov/retail/ecommerce.html"), ("FTC advertising", "https://www.ftc.gov/business-guidance/advertising-marketing")])
    add_sources_line(doc, [("Statistics Canada retail", "https://www150.statcan.gc.ca/n1/daily-quotidien/260211/dq260211b-eng.htm"), ("Canada languages", "https://www.canada.ca/en/immigration-refugees-citizenship/services/settle-canada/language-skills.html"), ("Competition Bureau", "https://competition-bureau.canada.ca/en/deceptive-marketing-practices/types-deceptive-marketing-practices/misleading-representations-and-deceptive-marketing-practices")])
    note = body(doc, "Source snapshot checked 21 November 2026. Refresh changing market and legal information before production use.", size=8.3, after=2)
    for run in note.runs:
        run.italic = True
        run.font.color.rgb = RGBColor.from_string(MUTED)

    # Page 9: database and information onboarding.
    add_page_break(doc)
    page_label(doc, "SYSTEM DATA  DATABASE AND BUSINESS ONBOARDING")
    heading(doc, "What the local SQLite databases contain")
    add_table(doc, ["Database / table", "Purpose"], [
        ("businesses", "Business identity, sector, home and example export markets, offer, audience, channel, goal, voice and call to action."),
        ("market_profiles", "Regional and country profiles with language and coverage notes."),
        ("knowledge_items", "Business facts and sourced market notes, each labelled by data status and source where available."),
        ("sources", "Publisher, title, URL, scope and checked date for public evidence."),
        ("marketing_examples", "Illustrative writing pattern and sample copy for each demo sector."),
        ("confirmation_checklist", "Business-owner facts to collect before publishing or making an offer."),
        ("accounts.sqlite3", "Separate local file at instance/accounts.sqlite3 for roles, activation-token hashes and session hashes; real account data is excluded from the lecturer package."),
    ], widths=[1.65, 5.2], font_size=8.6)
    heading(doc, "Information to collect from each real business", 2)
    add_table(doc, ["Category", "Examples to request"], [
        ("Offer and proof", "Products or services, specifications, ingredients, model/condition, deliverables, origin and supporting documents."),
        ("Commercial details", "Price and currency, stock or booking availability, offer period, delivery, shipping, returns and contact path."),
        ("Audience and markets", "Country, city, state or province, customer type, preferred language, channel and campaign goal."),
        ("Brand and examples", "Logo and approved colors, voice guidance, words to avoid, approved posts, creator examples and permission to reuse."),
        ("Performance", "Approved campaign outcomes and their measurement period; do not turn results into guarantees."),
    ], widths=[1.55, 5.3], font_size=8.6)
    callout(doc, "Data status rule", "Keep demo information labelled illustrative. Store a real claim only after its owner confirms it or a source supports it. Attach a source and review date to information that can change.", fill=PALE_GOLD)

    # Page 10: setup, limitations and acceptance.
    add_page_break(doc)
    page_label(doc, "SYSTEM OPERATION  SETUP AND ACCEPTANCE")
    heading(doc, "Run the local prototype and model")
    body(doc, "The web and account service uses Python 3 and the standard library. The local demo accepts passwords of 4 or more characters; use fictional credentials. The optional Qwen 3.5 4B package through Ollama is roughly 3.3 to 4 GB, with a separate runtime download. The computer has about 15.7 GB RAM and integrated Intel Iris Xe graphics, so measure response time before considering a larger model.")
    numbered(doc, 1, "Create the first admin", "From the project folder run python server.py --create-admin once. Enter an admin name, email and demo-only password of at least four characters.")
    numbered(doc, 2, "Start the website", "Run python server.py and open http://127.0.0.1:8766/ on this computer. Create user accounts in the browser; demo activation links appear on screen and in the server window.")
    numbered(doc, 3, "Finish the model download", "When connected to the internet, run offline_assistant\\setup_offline_model.ps1 in PowerShell. It installs Ollama if needed and downloads model weights.")
    numbered(doc, 4, "Start the assistant API", "Run offline_assistant\\start_offline_assistant.ps1 in a second PowerShell window. The Studio Guide should report that the model and database are connected.")
    numbered(doc, 5, "Rebuild data after edits", "From offline_assistant, run python scripts\\build_knowledge_db.py after updating the seed records.")
    heading(doc, "Current limits", 2)
    bullet(doc, "The five sample businesses and their product details are fictional; they are not researched client profiles.")
    bullet(doc, "Local account roles and activation are a demonstration only. No SMTP provider is configured; use fake credentials and set KIMUX_MIN_PASSWORD_LENGTH to 12 or more for production, alongside HTTPS and account-recovery controls. Production KimuX identity, APIs, campaign storage, publishing and deployment remain unconfirmed or unconnected.")
    bullet(doc, "Campaign drafts remain in this browser and are scoped to the signed-in demo account; they are not yet saved as server-side campaign records.")
    bullet(doc, "The local model setup is pending until both the Ollama runtime and model weights finish downloading.")
    bullet(doc, "Country-level legal, tax, import, labeling, platform and city-level audience coverage is only a starter set and needs current local research.")
    bullet(doc, "A local model can still make mistakes. A marketer must review each answer and approve every campaign before use.")
    heading(doc, "Acceptance checks for the next team review", 2)
    add_table(doc, ["Check", "Pass condition"], [
        ("Local operation", "After setup, a business question is answered by the local model and SQLite without a cloud AI API."),
        ("Grounded answer", "Market claims include source and date; fictional sample facts are identified as illustrative."),
        ("Unknown detail", "The assistant asks for confirmation when price, availability, proof or local rule is absent."),
        ("Market targeting", "It asks for an EAC country/city, U.S. state or Canadian province when needed."),
        ("Human control", "A user can edit the draft and visual and must review them before publication."),
        ("Account roles", "Public sign-up cannot assign admin; only an authenticated admin can change roles."),
        ("Activation", "Unactivated accounts cannot sign in; a one-time activation token is required."),
    ], widths=[1.45, 5.4], font_size=8.3)
    callout(doc, "Before a production connection", "Confirm KimuX's existing stack, identity and email provider, API and campaign-storage model, approved business-data sources, a maintained market-data review process, and secure server deployment.")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc.save(OUT)
    print(OUT)


if __name__ == "__main__":
    create_document()
