"""Build the local, source-aware KimuX business knowledge database.

Uses only Python's standard library. Re-run after editing seed records to rebuild
the SQLite file. Sample company and product details are fictional demo data.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "kimux_business_knowledge.sqlite3"
CHECKED_ON = "2026-11-22"

SOURCES = [
    ("EAC-Partner-States", "East African Community", "EAC Partner States", "https://www.eac.int/eac-partner-states", "Regional organization; membership"),
    ("EAC-Quick-Facts", "East African Community", "Quick Facts about EAC", "https://www.eac.int/eac-quick-facts", "Regional organization; institutional languages"),
    ("FTC-Advertising-Basics", "Federal Trade Commission", "Advertising and Marketing Basics", "https://www.ftc.gov/business-guidance/advertising-marketing", "United States; advertising claims"),
    ("FTC-Small-Business-FAQ", "Federal Trade Commission", "Advertising FAQs: A Guide for Small Business", "https://www.ftc.gov/business-guidance/resources/advertising-faqs-guide-small-business", "United States; advertising and state variation"),
    ("Canada-Language-Skills", "Government of Canada", "Improving your English and French", "https://www.canada.ca/en/immigration-refugees-citizenship/services/settle-canada/language-skills.html", "Canada; language distribution"),
    ("Canada-Misleading-Representations", "Competition Bureau Canada", "Misleading representations and deceptive marketing practices", "https://competition-bureau.canada.ca/en/deceptive-marketing-practices/types-deceptive-marketing-practices/misleading-representations-and-deceptive-marketing-practices", "Canada; marketing claims"),
    ("WB-Internet-Use", "World Bank / ITU", "Individuals using the Internet (% of population)", "https://data.worldbank.org/indicator/IT.NET.USER.ZS", "Country internet-use indicator; values below are 2024 snapshots"),
    ("US-Census-Population", "U.S. Census Bureau", "QuickFacts: United States", "https://www.census.gov/quickfacts/fact/table/US/PST045222", "United States; population estimate July 1, 2025"),
    ("US-Census-Ecommerce", "U.S. Census Bureau", "Quarterly Retail E-Commerce Sales, Third Quarter 2026", "https://www.census.gov/retail/ecommerce.html", "United States; e-commerce sales Q3 2026"),
    ("StatsCan-Population", "Statistics Canada", "Population estimates on July 1, by age and gender", "https://www150.statcan.gc.ca/t1/tbl1/en/tv.action?pid=1710000501", "Canada; population estimate July 1, 2026"),
    ("StatsCan-Retail", "Statistics Canada", "Annual retail trade, 2024", "https://www150.statcan.gc.ca/n1/daily-quotidien/260211/dq260211b-eng.htm", "Canada; annual retail and e-commerce revenue 2024"),
    ("UCDA-Coffee-Prices", "Uganda Coffee Development Authority", "Statistics: daily coffee market prices", "https://new.ugandacoffee.go.ug/index.php/resource-center/statistics", "Uganda; daily coffee prices by grade. Confirm price stage, currency and unit on each source record before use."),
    ("ICO-Public-Coffee-Market", "International Coffee Organization", "Public Market Information", "https://ico.org/resources/public-market-information/", "Global daily indicator prices and trade information; detailed historical data may require access or payment."),
    ("US-BLS-Coffee-Prices", "U.S. Bureau of Labor Statistics", "CPI: Average Price Data", "https://www.bls.gov/cpi/factsheets/average-prices.htm", "United States; selected consumer retail price series. Check item definition, geography and reference month."),
    ("StatsCan-Coffee-Prices", "Statistics Canada", "Monthly average retail prices for selected products (table 18-10-0245-01)", "https://www150.statcan.gc.ca/t1/table?pid=1810024501", "Canada; monthly scanner-based average retail prices, with product and provincial coverage. Product mix can change."),
    ("USDA-Coffee-World-Markets", "USDA Foreign Agricultural Service", "Coffee: World Markets and Trade, July 2026", "https://apps.fas.usda.gov/psdonline/circulars/coffee.pdf", "Country-level coffee imports and consumption; marketing-year estimates/forecasts, not local retail prices or customer-level demand."),
    ("Rwanda-NAEB-Coffee-2025", "National Agricultural Export Development Board (Rwanda)", "Rwanda coffee export revenues hit record $150m in 2025", "https://www.naeb.gov.rw/publications/news/rwanda-coffee-export-revenues-hit-record-150m-in-2025", "Rwanda; 2025 green-coffee exports, average export price and farm-gate price. Not retail pricing."),
]

BUSINESSES = [
    {
        "id": "coffee", "name": "Lakeview Coffee Co.", "sector": "Coffee",
        "home_market": "Kampala, Uganda", "example_export_market": "Dubai, UAE",
        "product": "Single-origin Arabica",
        "facts": "Ugandan Arabica; medium roast; 250 g pack; roasted weekly in small batches.",
        "local_audience": "Coffee drinkers looking for locally sourced beans",
        "export_audience": "Coffee importers and distributors comparing Ugandan origin supply",
        "channel": "Instagram", "goal": "Product awareness", "language": "English",
        "tone": "Warm and confident", "visual_style": "Warm & organic",
        "cta": "Explore the collection", "hook": "A clear origin. A thoughtful roast.",
        "direct_hook": "Meet a coffee with a clear origin.", "warm_hook": "Make room for a more thoughtful coffee moment.",
        "example_pattern": "Origin -> product detail -> one clear action",
        "example_copy": "Ugandan Arabica, medium roast, roasted weekly in small batches. Explore the collection.",
        "confirmation": [
            "Confirm farm or region of origin, processing method, certifications, price, stock and pack sizes before using them in copy.",
            "For export campaigns, confirm packaging, volume, shipping terms, destination rules and any certifications from current sources.",
        ],
    },
    {
        "id": "auto", "name": "Northstar Auto", "sector": "Automotive",
        "home_market": "Kampala, Uganda", "example_export_market": "Kigali, Rwanda",
        "product": "2021 Cityline compact SUV",
        "facts": "2021 model; automatic transmission; 58,000 km; 2.0 L petrol engine.",
        "local_audience": "Drivers comparing practical city vehicles",
        "export_audience": "Regional fleet buyers and vehicle resellers",
        "channel": "Facebook", "goal": "Get enquiries", "language": "English",
        "tone": "Clear and direct", "visual_style": "Clean & direct",
        "cta": "Book a viewing", "hook": "Your next drive starts with the right details.",
        "direct_hook": "Explore a vehicle that fits your next drive.", "warm_hook": "A little more confidence for the road ahead.",
        "example_pattern": "Buyer need -> verified specification -> next step",
        "example_copy": "A 2021 compact SUV with automatic transmission and 58,000 km. Book a viewing.",
        "confirmation": [
            "Confirm mileage, vehicle condition, service history, accident history, title or ownership, price and availability before publication.",
            "For cross-border offers, confirm destination import eligibility, taxes, inspection, shipping and documentation with current official sources.",
        ],
    },
    {
        "id": "fashion", "name": "Atelier Nia", "sector": "Fashion",
        "home_market": "Kampala, Uganda", "example_export_market": "Nairobi, Kenya",
        "product": "Indigo wrap shirt",
        "facts": "Cotton fabric; indigo blue; sizes S to XL; adjustable wrap tie.",
        "local_audience": "Style-conscious shoppers looking for versatile pieces",
        "export_audience": "Boutiques seeking East African contemporary labels",
        "channel": "Instagram", "goal": "Product awareness", "language": "English",
        "tone": "Warm and confident", "visual_style": "Premium & minimal",
        "cta": "Shop the new edit", "hook": "Everyday style, made versatile.",
        "direct_hook": "Discover a piece made for versatile styling.", "warm_hook": "A fresh favorite for the way you move.",
        "example_pattern": "Product appeal -> material and size facts -> action",
        "example_copy": "An indigo cotton wrap shirt, available in sizes S to XL. Shop the new edit.",
        "confirmation": [
            "Confirm material composition, care instructions, fit, size chart, available stock, price, origin claims and returns policy.",
            "Ask which country and province or state is targeted before giving labeling or consumer-rule guidance.",
        ],
    },
    {
        "id": "design", "name": "Form & Field Studio", "sector": "Design services",
        "home_market": "Kampala and remote", "example_export_market": "East Africa",
        "product": "Brand identity starter package",
        "facts": "Logo suite; color palette; and three editable social templates.",
        "local_audience": "Small businesses preparing to launch or refresh",
        "export_audience": "Startups and SMEs preparing a brand launch",
        "channel": "LinkedIn", "goal": "Get enquiries", "language": "English",
        "tone": "Clear and direct", "visual_style": "Clean & direct",
        "cta": "Book a discovery call", "hook": "Make your brand easier to recognize.",
        "direct_hook": "Build a clearer brand identity.", "warm_hook": "Give your next idea a visual home.",
        "example_pattern": "Customer outcome -> named deliverables -> conversation",
        "example_copy": "A starter identity package with a logo suite, color palette and three editable social templates. Book a discovery call.",
        "confirmation": [
            "Confirm deliverables, revision limits, timeline, pricing, ownership or licensing terms, process and what the client must provide.",
            "Only use client results, testimonials and performance claims when their owner has approved the wording and evidence.",
        ],
    },
    {
        "id": "food", "name": "Malaika Kitchen", "sector": "Food service",
        "home_market": "Kampala, Uganda", "example_export_market": "Nairobi, Kenya",
        "product": "Smoky groundnut stew",
        "facts": "Groundnuts, tomatoes and greens; prepared fresh to order. Contains groundnuts.",
        "local_audience": "Lunch seekers who enjoy local comfort food",
        "export_audience": "Cafe and food-service buyers sourcing local dishes",
        "channel": "Instagram", "goal": "Drive a purchase", "language": "English",
        "tone": "Energetic and friendly", "visual_style": "Bold & energetic",
        "cta": "Order today's special", "hook": "A familiar favorite, served fresh.",
        "direct_hook": "Discover today's local kitchen special.", "warm_hook": "Bring a comforting favorite to the table.",
        "example_pattern": "Dish -> ingredients or preparation -> clear action + allergen",
        "example_copy": "Smoky groundnut stew with tomatoes and greens, prepared fresh to order. Contains groundnuts. Order today's special.",
        "confirmation": [
            "Confirm the full ingredient list, allergen cross-contact details, serving size, price, availability, storage and preparation claims with the kitchen.",
            "Do not infer nutrition, health, organic, freshness or safety claims from a dish name or photo.",
        ],
    },
]

MARKET_PROFILES = [
    ("EAC", "East African Community", "regional", "EAC Partner States", "English, Kiswahili, French at Community level", "The EAC lists eight Partner States. Do not treat the region as one country, one currency, one language audience or one regulatory jurisdiction. Ask the user to name the target country and city before drafting localized advice."),
    ("UG", "Uganda", "country", "East African Community", "Confirm audience language and district/city", "EAC member. The current knowledge pack contains a Kampala demo profile only; it does not establish national market size, consumer behavior, local regulation or current prices."),
    ("KE", "Kenya", "country", "East African Community", "Confirm audience language and county/city", "EAC member. The current knowledge pack contains a Nairobi demo export audience only; it does not establish national market size, consumer behavior, local regulation or current prices."),
    ("RW", "Rwanda", "country", "East African Community", "Confirm audience language and district/city", "EAC member. The current knowledge pack contains a Kigali demo export audience only; it does not establish national market size, consumer behavior, local regulation or current prices."),
    ("TZ", "Tanzania", "country", "East African Community", "Confirm audience language and region/city", "EAC member. Detailed Tanzania market and legal data are not yet curated in this pack."),
    ("BI", "Burundi", "country", "East African Community", "Confirm audience language and province/city", "EAC member. Detailed Burundi market and legal data are not yet curated in this pack."),
    ("SS", "South Sudan", "country", "East African Community", "Confirm audience language and state/city", "EAC member. Detailed South Sudan market and legal data are not yet curated in this pack."),
    ("CD", "Democratic Republic of the Congo", "country", "East African Community", "Confirm audience language and province/city", "EAC member. Detailed DRC market and legal data are not yet curated in this pack."),
    ("SO", "Somalia", "country", "East African Community", "Confirm audience language and region/city", "EAC member. Detailed Somalia market and legal data are not yet curated in this pack."),
    ("US", "United States", "country", "North America", "Ask for language, state and city; do not presume a single audience", "Ask for the state and city, product category, channel and intended claim. Federal advertising guidance exists alongside state consumer-protection rules and specialized product rules."),
    ("CA", "Canada", "country", "North America", "English and French are federal official languages; ask for province/city and audience language", "Ask for province and city. Canada-wide information does not settle province-specific requirements or specialized product rules; use current official sources for legal or compliance questions."),
]

MARKET_FACTS = [
    ("EAC", "regional_membership", "The East African Community lists eight Partner States: Burundi, Democratic Republic of the Congo, Kenya, Rwanda, Somalia, South Sudan, Tanzania and Uganda.", "source_checked_official", "EAC-Partner-States"),
    ("EAC", "institutional_languages", "The EAC lists English, Kiswahili and French as official languages of the Community. This is an institutional fact, not a guarantee that a particular customer prefers any one of them.", "source_checked_official", "EAC-Quick-Facts"),
    ("EAC", "market_scale", "The EAC quick-facts page reports a population of 331.1 million for 2023 and GDP at current market prices of US$356 billion for 2024. These regional aggregates provide context; they are not a business's addressable market or a forecast of demand.", "source_checked_official", "EAC-Quick-Facts"),
    ("EAC", "localization", "Treat East Africa as a collection of country and city audiences. Ask for destination country, city, audience language, currency, channel and product category before writing localized copy.", "curation_rule", None),
    ("UG", "internet_use", "World Bank/ITU indicator: 8.95% of Uganda's population used the Internet in 2024. This national indicator is not a Kampala reach estimate or a count of likely buyers; use city-level audience and channel research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("KE", "internet_use", "World Bank/ITU indicator: 34.98% of Kenya's population used the Internet in 2024. This national indicator is not a Nairobi reach estimate or a count of likely buyers; use city-level audience and channel research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("RW", "internet_use", "World Bank/ITU indicator: 31.70% of Rwanda's population used the Internet in 2024. This national indicator is not a Kigali reach estimate or a count of likely buyers; use city-level audience and channel research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("TZ", "internet_use", "World Bank/ITU indicator: 31.16% of Tanzania's population used the Internet in 2024. This national indicator is not a city-level reach estimate or a count of likely buyers; use city and channel research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("BI", "internet_use", "World Bank/ITU indicator: 8.60% of Burundi's population used the Internet in 2024. This national indicator is not a city-level reach estimate or a count of likely buyers; use local audience research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("CD", "internet_use", "World Bank/ITU indicator: 19.67% of the Democratic Republic of the Congo's population used the Internet in 2024. This national indicator is not a city-level reach estimate or a count of likely buyers; use local audience research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("SO", "internet_use", "World Bank/ITU indicator: 27.94% of Somalia's population used the Internet in 2024. This national indicator is not a city-level reach estimate or a count of likely buyers; use local audience research before planning spend.", "source_checked_official", "WB-Internet-Use"),
    ("SS", "internet_use_data_gap", "No 2024 value was returned for South Sudan in the World Bank/ITU internet-use series during this database build. Do not estimate it from another EAC country; retrieve a newer official value before answering.", "source_checked_official", "WB-Internet-Use"),
    ("US", "population", "U.S. Census Bureau QuickFacts estimates the United States population at 341,784,857 on July 1, 2025. This is national context, not the size of a target customer segment.", "source_checked_official", "US-Census-Population"),
    ("US", "ecommerce", "U.S. Census Bureau reported Q3 2026 retail e-commerce sales of US$347.3 billion, 17.9% of total retail sales (seasonally adjusted; not adjusted for price changes). This describes retail broadly, not demand for a particular KimuX client.", "source_checked_official", "US-Census-Ecommerce"),
    ("US", "internet_use", "World Bank/ITU indicator: 94.69% of the United States population used the Internet in 2024. This is a national access measure, not an addressable customer segment.", "source_checked_official", "WB-Internet-Use"),
    ("UG", "demo_scope", "The business examples currently describe a fictional Kampala, Uganda home market. They do not provide verified Uganda market research or current legal requirements.", "prototype_scope", None),
    ("UG", "coffee_price_data_gap", "UCDA publishes daily coffee market prices by grade. For this prototype, do not treat a listed value as a retail price or import it without recording its date, price stage, currency, unit and grade; the source page's extracted listing did not make all of those fields clear together.", "source_checked_official", "UCDA-Coffee-Prices"),
    ("KE", "demo_scope", "The business examples currently use Nairobi, Kenya as an illustrative export market. They do not provide verified Kenya market research or current legal requirements.", "prototype_scope", None),
    ("RW", "demo_scope", "The Northstar Auto sample uses Kigali, Rwanda as an illustrative export market. It does not provide verified Rwanda market research or current import requirements.", "prototype_scope", None),
    ("RW", "coffee_market_scope", "Rwanda's 2025 coffee export and farm-gate figures are available as national historical indicators. They do not describe retail coffee prices in Kigali or establish demand for a particular roaster.", "source_checked_official", "Rwanda-NAEB-Coffee-2025"),
    ("US", "advertising_claims", "The FTC says advertising claims must be truthful, not deceptive or unfair, and evidence-based. Specialized products and services may have additional rules.", "source_checked_official", "FTC-Advertising-Basics"),
    ("US", "state_variation", "The FTC small-business guide notes that every state has consumer-protection laws that govern advertisements running in that state. Ask for the state before providing specific guidance.", "source_checked_official", "FTC-Small-Business-FAQ"),
    ("CA", "languages", "Canada has two official languages, English and French. English is most commonly spoken in most provinces; French is the main language in Quebec and some areas of Ontario, New Brunswick and Manitoba. Ask for province and target audience.", "source_checked_official", "Canada-Language-Skills"),
    ("CA", "population", "Statistics Canada estimates Canada's population at 41,798,407 on July 1, 2026. This is national context, not the size of a target customer segment.", "source_checked_official", "StatsCan-Population"),
    ("CA", "ecommerce", "Statistics Canada's 2024 annual retail trade release reports retail e-commerce revenue of C$73.7 billion, up 9.0% year over year, within total retail operating revenue of C$865.2 billion. This is a historical national indicator, not a forecast or client-specific demand.", "source_checked_official", "StatsCan-Retail"),
    ("CA", "internet_use", "World Bank/ITU indicator: 94.35% of Canada's population used the Internet in 2024. This is a national access measure, not an addressable customer segment.", "source_checked_official", "WB-Internet-Use"),
    ("CA", "auto_retail", "Statistics Canada's 2024 annual retail trade release reports motor vehicle and parts dealer revenue increased 5.0% in 2024. It does not establish demand for any specific vehicle or brand.", "source_checked_official", "StatsCan-Retail"),
    ("CA", "advertising_claims", "Canada's Competition Bureau says false or misleading material representations are prohibited. Performance, effectiveness or product-life claims must be based on an adequate and proper test.", "source_checked_official", "Canada-Misleading-Representations"),
    ("CA", "localization", "Do not assume one language or one province-wide audience. Ask whether the campaign targets English, French or both and identify the province and city before drafting.", "curation_rule", None),
    ("ALL", "source_freshness", "Market law, tariffs, prices, availability, platform rules and import requirements can change. For these questions, retrieve a current official source and show its effective or checked date; if no current source is available, say so.", "assistant_safety_rule", None),
]

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS sources (
    source_id TEXT PRIMARY KEY,
    publisher TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    scope TEXT NOT NULL,
    checked_on TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS market_profiles (
    market_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    level TEXT NOT NULL,
    region TEXT NOT NULL,
    language_notes TEXT NOT NULL,
    scope_notes TEXT NOT NULL,
    checked_on TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS businesses (
    business_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    sector TEXT NOT NULL,
    home_market TEXT NOT NULL,
    example_export_market TEXT NOT NULL,
    product_or_service TEXT NOT NULL,
    local_audience TEXT NOT NULL,
    export_audience TEXT NOT NULL,
    primary_channel TEXT NOT NULL,
    campaign_goal TEXT NOT NULL,
    language TEXT NOT NULL,
    tone TEXT NOT NULL,
    visual_style TEXT NOT NULL,
    call_to_action TEXT NOT NULL,
    fictional_demo INTEGER NOT NULL DEFAULT 1 CHECK(fictional_demo IN (0,1)),
    data_status TEXT NOT NULL DEFAULT 'illustrative_unverified'
);
CREATE TABLE IF NOT EXISTS knowledge_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id TEXT REFERENCES businesses(business_id) ON DELETE CASCADE,
    market_id TEXT REFERENCES market_profiles(market_id),
    category TEXT NOT NULL,
    content TEXT NOT NULL,
    data_status TEXT NOT NULL,
    source_id TEXT REFERENCES sources(source_id),
    checked_on TEXT,
    UNIQUE(business_id, market_id, category, content)
);
CREATE TABLE IF NOT EXISTS market_observations (
    observation_id TEXT PRIMARY KEY,
    sector TEXT NOT NULL,
    market_id TEXT NOT NULL REFERENCES market_profiles(market_id),
    geography TEXT NOT NULL,
    metric TEXT NOT NULL,
    metric_kind TEXT NOT NULL,
    product_form TEXT NOT NULL,
    value_num REAL NOT NULL,
    currency TEXT,
    unit TEXT NOT NULL,
    period TEXT NOT NULL,
    observed_on TEXT NOT NULL,
    source_id TEXT NOT NULL REFERENCES sources(source_id),
    data_status TEXT NOT NULL,
    caveat TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS marketing_examples (
    example_id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id TEXT NOT NULL REFERENCES businesses(business_id) ON DELETE CASCADE,
    pattern TEXT NOT NULL,
    example_copy TEXT NOT NULL,
    data_status TEXT NOT NULL DEFAULT 'illustrative_not_approved'
);
CREATE TABLE IF NOT EXISTS confirmation_checklist (
    checklist_id INTEGER PRIMARY KEY AUTOINCREMENT,
    business_id TEXT NOT NULL REFERENCES businesses(business_id) ON DELETE CASCADE,
    item TEXT NOT NULL,
    data_status TEXT NOT NULL DEFAULT 'request_from_business_owner'
);
CREATE INDEX IF NOT EXISTS idx_knowledge_business ON knowledge_items(business_id);
CREATE INDEX IF NOT EXISTS idx_knowledge_market ON knowledge_items(market_id);
CREATE INDEX IF NOT EXISTS idx_observations_market_sector ON market_observations(market_id, sector);
"""

MARKET_OBSERVATIONS = [
    # USDA values are in thousand 60-kg bags and are forecast estimates for the 2026/27 marketing year (July 2026 release).
    ("US-COFFEE-BEAN-IMPORTS-2026-27", "coffee", "US", "United States", "Bean imports", "trade_volume", "green coffee beans", 24500, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, city estimate or addressable-customer count."),
    ("US-COFFEE-ROAST-GROUND-IMPORTS-2026-27", "coffee", "US", "United States", "Roast and ground imports", "trade_volume", "roast and ground coffee", 900, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, city estimate or addressable-customer count."),
    ("US-COFFEE-SOLUBLE-IMPORTS-2026-27", "coffee", "US", "United States", "Soluble imports", "trade_volume", "soluble coffee", 1500, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, city estimate or addressable-customer count."),
    ("US-COFFEE-TOTAL-IMPORTS-2026-27", "coffee", "US", "United States", "Total imports", "trade_volume", "all coffee forms, green-bean equivalent", 26900, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; conversions are used for roasted and soluble coffee. Not retail demand."),
    ("US-COFFEE-CONSUMPTION-2026-27", "coffee", "US", "United States", "Domestic consumption", "consumption", "all coffee forms, green-bean equivalent", 26950, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity estimate; not demand for a specific brand, specialty grade or city."),
    ("CA-COFFEE-BEAN-IMPORTS-2026-27", "coffee", "CA", "Canada", "Bean imports", "trade_volume", "green coffee beans", 3200, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, provincial estimate or addressable-customer count."),
    ("CA-COFFEE-ROAST-GROUND-IMPORTS-2026-27", "coffee", "CA", "Canada", "Roast and ground imports", "trade_volume", "roast and ground coffee", 200, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, provincial estimate or addressable-customer count."),
    ("CA-COFFEE-SOLUBLE-IMPORTS-2026-27", "coffee", "CA", "Canada", "Soluble imports", "trade_volume", "soluble coffee", 1700, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; not a retail price, provincial estimate or addressable-customer count."),
    ("CA-COFFEE-TOTAL-IMPORTS-2026-27", "coffee", "CA", "Canada", "Total imports", "trade_volume", "all coffee forms, green-bean equivalent", 5100, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity flow; conversions are used for roasted and soluble coffee. Not retail demand."),
    ("CA-COFFEE-CONSUMPTION-2026-27", "coffee", "CA", "Canada", "Domestic consumption", "consumption", "all coffee forms, green-bean equivalent", 5100, None, "thousand 60-kg bags", "2026/27 marketing year estimate", "2026-07", "USDA-Coffee-World-Markets", "official_forecast", "National commodity estimate; not demand for a specific brand, specialty grade or province."),
    ("RW-COFFEE-EXPORT-PRICE-2025", "coffee", "RW", "Rwanda", "Average green-coffee export price", "export_price", "green coffee", 6.2, "USD", "per kg", "calendar year 2025", "2025", "Rwanda-NAEB-Coffee-2025", "official_historical", "National average export price; not a farm-gate or consumer retail price."),
    ("RW-COFFEE-FARMGATE-2025", "coffee", "RW", "Rwanda", "Average farm-gate price", "farm_gate_price", "coffee cherries", 900, "RWF", "per kg", "calendar year 2025", "2025", "Rwanda-NAEB-Coffee-2025", "official_historical", "National average paid for cherries; not a green-bean export or consumer retail price."),
    ("RW-COFFEE-EXPORT-VOLUME-2025", "coffee", "RW", "Rwanda", "Green-coffee exports", "trade_volume", "green coffee", 23860, None, "tonnes", "calendar year 2025", "2025", "Rwanda-NAEB-Coffee-2025", "official_historical", "National export volume; not domestic consumption or demand for a particular brand."),
]


def build() -> None:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        DB_PATH.unlink()
    with sqlite3.connect(DB_PATH) as con:
        con.executescript(SCHEMA)
        con.executemany(
            "INSERT INTO sources(source_id,publisher,title,url,scope,checked_on) VALUES(?,?,?,?,?,?)",
            [(sid, pub, title, url, scope, CHECKED_ON) for sid, pub, title, url, scope in SOURCES],
        )
        con.executemany(
            "INSERT INTO market_profiles(market_id,name,level,region,language_notes,scope_notes,checked_on) VALUES(?,?,?,?,?,?,?)",
            [(*row, CHECKED_ON) for row in MARKET_PROFILES],
        )
        for b in BUSINESSES:
            con.execute(
                """INSERT INTO businesses(
                    business_id,display_name,sector,home_market,example_export_market,
                    product_or_service,local_audience,export_audience,primary_channel,
                    campaign_goal,language,tone,visual_style,call_to_action,fictional_demo,data_status
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,'illustrative_unverified')""",
                (b["id"], b["name"], b["sector"], b["home_market"], b["example_export_market"],
                 b["product"], b["local_audience"], b["export_audience"], b["channel"], b["goal"],
                 b["language"], b["tone"], b["visual_style"], b["cta"]),
            )
            facts = [
                ("product_facts", b["facts"]), ("example_hook", b["hook"]),
                ("direct_hook", b["direct_hook"]), ("warm_hook", b["warm_hook"]),
            ]
            for category, content in facts:
                con.execute(
                    "INSERT INTO knowledge_items(business_id,category,content,data_status) VALUES(?,?,?,'illustrative_unverified')",
                    (b["id"], category, content),
                )
            con.execute(
                "INSERT INTO marketing_examples(business_id,pattern,example_copy) VALUES(?,?,?)",
                (b["id"], b["example_pattern"], b["example_copy"]),
            )
            con.executemany(
                "INSERT INTO confirmation_checklist(business_id,item) VALUES(?,?)",
                [(b["id"], item) for item in b["confirmation"]],
            )
        for market_id, category, content, status, source_id in MARKET_FACTS:
            con.execute(
                "INSERT INTO knowledge_items(market_id,category,content,data_status,source_id,checked_on) VALUES(?,?,?,?,?,?)",
                (None if market_id == "ALL" else market_id, category, content, status, source_id, CHECKED_ON if source_id else None),
            )
        con.executemany(
            """INSERT INTO market_observations(
                observation_id,sector,market_id,geography,metric,metric_kind,product_form,
                value_num,currency,unit,period,observed_on,source_id,data_status,caveat
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            MARKET_OBSERVATIONS,
        )
        con.commit()
    print(f"Created {DB_PATH}")
    print(f"Seeded {len(BUSINESSES)} fictional businesses, {len(MARKET_PROFILES)} market profiles, {len(MARKET_FACTS)} market facts, {len(MARKET_OBSERVATIONS)} coffee observations and {len(SOURCES)} source records.")


if __name__ == "__main__":
    build()
