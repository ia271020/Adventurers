$ErrorActionPreference = "Stop"
$assistantRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$modelName = if ($env:KIMUX_LOCAL_MODEL) { $env:KIMUX_LOCAL_MODEL } else { "qwen3.5:0.8b" }
$chatModelName = if ($env:KIMUX_CHAT_MODEL) { $env:KIMUX_CHAT_MODEL } else { "qwen3.5:4b" }
$ollamaCommand = Get-Command ollama -ErrorAction SilentlyContinue
$candidatePaths = @(
  "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe",
  "$env:ProgramFiles\Ollama\ollama.exe",
  "$env:LOCALAPPDATA\Ollama\ollama.exe"
)
$ollamaExe = if ($ollamaCommand) { $ollamaCommand.Source } else { $candidatePaths | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1 }

if (-not $ollamaExe) {
  Write-Host "Ollama is not installed. Install it once, then run this script again." -ForegroundColor Yellow
  Write-Host "Official download: https://ollama.com/download/windows"
  exit 1
}

$tagsUri = "http://127.0.0.1:11434/api/tags"
try {
  Invoke-RestMethod -Uri $tagsUri -TimeoutSec 2 | Out-Null
} catch {
  Write-Host "Starting the local Ollama service…"
  Start-Process -FilePath $ollamaExe -ArgumentList "serve" -WindowStyle Hidden
  $ready = $false
  for ($attempt = 0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Seconds 1
    try { Invoke-RestMethod -Uri $tagsUri -TimeoutSec 2 | Out-Null; $ready = $true; break } catch { }
  }
  if (-not $ready) {
    Write-Host "Ollama did not start. Open Ollama once from the Start menu and retry." -ForegroundColor Red
    exit 1
  }
}

$installed = Invoke-RestMethod -Uri $tagsUri -TimeoutSec 5
$hasModel = @($installed.models | Where-Object { $_.name -eq $modelName -or $_.name -eq ($modelName + ":latest") }).Count -gt 0
if (-not $hasModel) {
  Write-Host "The one-time model download is missing. While connected to the internet, run:" -ForegroundColor Yellow
  Write-Host "ollama pull $modelName" -ForegroundColor Cyan
  Write-Host "After that download completes, this assistant runs locally without internet."
  exit 1
}
$hasChatModel = @($installed.models | Where-Object { $_.name -eq $chatModelName -or $_.name -eq ($chatModelName + ":latest") }).Count -gt 0
if (-not $hasChatModel) {
  $chatModelName = $modelName
  Write-Host "The larger chat model is not installed; the chat will use the campaign model. Optional download: ollama pull qwen3.5:4b" -ForegroundColor Yellow
}

$env:KIMUX_LOCAL_MODEL = $modelName
$env:KIMUX_CHAT_MODEL = $chatModelName
$modelsToWarm = @($modelName)
if ($chatModelName -ne $modelName) { $modelsToWarm += $chatModelName }
foreach ($warmModel in $modelsToWarm) {
  Write-Host "Warming $warmModel before the demo…"
  $warmBody = @{
    model = $warmModel
    prompt = "Reply with READY."
    stream = $false
    think = $false
    keep_alive = "30m"
    options = @{ num_ctx = 4096; num_predict = 1 }
  } | ConvertTo-Json -Depth 4 -Compress
  try {
    Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/generate" -Method Post -ContentType "application/json" -Body $warmBody -TimeoutSec 120 | Out-Null
    Write-Host "$warmModel is ready."
  } catch {
    Write-Host "Warm-up of $warmModel did not finish. The first request may take longer." -ForegroundColor Yellow
  }
}

Write-Host "Starting the KimuX offline assistant on http://127.0.0.1:8767"
Write-Host "Campaign generation/review model: $modelName"
Write-Host "Chat model: $chatModelName"
Write-Host "Leave this PowerShell window open while using the local site. Press Ctrl+C to stop."
python (Join-Path $assistantRoot "scripts\offline_assistant_server.py")
