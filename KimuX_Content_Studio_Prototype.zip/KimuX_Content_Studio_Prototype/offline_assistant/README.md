# KimuX offline business assistant data pack

This folder contains the first local knowledge database for a private, offline KimuX business assistant.

## What it covers

- Five **fictional demo businesses** carried over from the Content Studio: coffee, automotive, fashion, design services, and food service.
- East African Community (EAC) regional membership and institutional-language facts, plus country prompts for all eight Partner States.
- Initial United States advertising-claim guidance from the FTC.
- Initial Canadian language and advertising-claim guidance from Government of Canada and Competition Bureau sources.
- Coffee market source references and 13 structured observations covering U.S. and Canadian import/consumption estimates and Rwanda's 2025 export/farm-gate indicators.
- Business-owner confirmation checklists for facts that must not be guessed, such as price, availability, certifications, allergens, vehicle condition, and service terms.

The database separates official-source facts from demo-only business information and assistant guidance. All sample company names, product details, audiences, hooks, and example copy are fictional and unverified. They must never be represented as real KimuX clients or market research.

## Build the database

From this folder, run:

```powershell
python scripts\build_knowledge_db.py
```

The resulting SQLite database is `data\kimux_business_knowledge.sqlite3`. The builder uses only Python's standard library. `market_observations` stores sector, market, metric, value, unit, period, observation date, source and caveat. Market sources are recorded in `sources` with URLs and a checked date; refresh changing market and legal information before relying on it.

## Offline-model design

The assistant uses downloaded local language models plus retrieval from SQLite (RAG). Campaign generation and review use `qwen3.5:0.8b` by default for a quicker CPU demo. Studio Guide chat prefers `qwen3.5:4b` when installed and falls back to the 0.8B model if it is not. The 4B chat model is optional and can take longer on this laptop. Model files must be downloaded once while online; inference and the business database run on this computer afterward. [Ollama model details](https://ollama.com/library/qwen3.5).

The local endpoint is `scripts\offline_assistant_server.py`, bound to `127.0.0.1:8767`. It calls only Ollama at `127.0.0.1:11434` and reads SQLite; it contains no external AI API key or cloud fallback. The Content Studio uses it for three local-only tasks:

- `/api/chat` retrieves business and market records to answer Studio Guide questions.
- `/api/generate` creates, optimizes, and revises campaign copy using the selected audience, market, objective, channel, tone, language, and verified brief facts.
- `/api/review` returns advisory 0–5 ratings and reasons for relevance, clarity, audience fit, tone fit, platform fit, and factual support. The app normalizes the six ratings to a 0–100 summary; this is model feedback, not a measured outcome or approval. It runs only when requested so a review does not double the wait for every draft.

The campaign prompt uses the selected sample's writing pattern as an explicitly fictional style example, never as evidence for product claims. Replace these examples with content reviewed by KimuX marketing experts and add approved brand rules before a connected release. The model is prompted to avoid adding unsupported product facts, but people still need to verify all generated copy.

After installing Ollama and downloading the default model (`ollama pull qwen3.5:0.8b`), start `start_offline_assistant.ps1` before the presentation. Optionally add the larger chat model with `ollama pull qwen3.5:4b`. Startup warms each installed model, then keeps it loaded for 30 minutes after a request. The model answers from retrieved records, says when a fact is missing, and distinguishes official-source market information from fictional demo examples. This is retrieval-augmented answering and prompting, not fine-tuning on an unfiltered internet dump. Use curated, approved marketer examples to improve style; update sourced database records to refresh prices and market facts.

The initial market coverage is deliberately a starter pack, not complete country research. It includes EAC membership, institutional languages and regional scale; 2024 World Bank/ITU internet-use snapshots for EAC countries where reported; U.S. population, retail e-commerce and FTC guidance; Canadian population, retail e-commerce, language and Competition Bureau guidance; and prompts covering all eight EAC countries. Statistics include their data periods and must not be treated as a client-specific addressable market. Before production, add approved company material, country and city profiles, local audience research, brand guidelines, platform requirements, permitted claims, and relevant official sources with review dates. Rules and market figures that can change need an update owner and review schedule.

## Coffee market evidence and remaining data gaps

The first coffee pack is intentionally modest and keeps the measure type visible:

| Market | Data currently loaded | What it supports | What it does not support |
| --- | --- | --- | --- |
| United States | USDA FAS 2026/27 estimate: bean, roasted/ground and soluble imports; total imports; domestic consumption | Country-level commodity flow and broad consumption context | Retail shelf price, city demand, specialty-coffee segment size, or demand for one brand |
| Canada | USDA FAS 2026/27 estimate: the same import forms and domestic consumption | Country-level commodity flow and broad consumption context | Provincial retail price or demand for a particular product |
| Rwanda | NAEB 2025 green-coffee export volume and average export price; average farm-gate cherry price | Historical supplier-side price and export context | Kigali consumer retail price or a current offer price |
| Uganda | UCDA daily price source is catalogued; no numeric price is loaded yet | Identifies the official series to review | Do not quote a figure until its grade, price stage, currency, unit and date are verified together |
| United States / Canada retail | BLS and Statistics Canada retail-price sources are catalogued; no numeric series has been imported yet | Identifies official retail reference series | These source pages do not establish a current local price until a row and product definition are loaded |

The other catalogued market reference is the International Coffee Organization's daily composite/group indicator and trade information. Some historical series and detailed breakdowns require access or payment. Confirm reuse rights and update frequency before collecting any online dataset.

Each future observation should retain product or grade, geography, metric, price stage, value, currency, unit/pack, period, observation date, source, access date, data status and a caveat. Keep farm-gate, export, wholesale and consumer retail values separate. National imports or consumption are market context, not proof that a specific brand will sell. Do not use a broad internet scrape as model training data. Keep the local model fixed and retrieve only relevant, licensed, dated rows from SQLite; it is easier to update and cite.

## Chatbot quality issues recorded

- Before the compact retrieval change, a 0.8B chat answer took about 19 seconds and still asked for a city already in the brief. A 4B answer with the full context took about 60 seconds, was too long and included an invented citation and unsupported details.
- Broad country-level rows could be included in a coffee question even when they did not answer it. Chat retrieval now prefers the explicitly requested market and prioritizes matching facts. Simple facts, prices and consumption use direct SQLite answers where a matching observation exists.
- Price questions now require an imported observation with a date, price type, geography, currency/unit and product form. When it is missing, the chatbot says so instead of guessing. The 4B model is preferred for free-form Guide questions when installed; the faster 0.8B remains the campaign model and fallback.
- The live dataset still has no current Uganda consumer shelf prices, U.S./Canadian local retail rows, city-level competitor prices or brand-specific demand. Sourcing and refreshing those datasets is the next research task. All model-written campaign text and unstructured answers still need human review.

## One-time local model setup

Run `setup_offline_model.ps1` in PowerShell while connected to the internet. It installs Ollama if needed and downloads the default fast-demo model `qwen3.5:0.8b` if it is missing. If you choose the larger model on another computer, set `$env:KIMUX_LOCAL_MODEL = "qwen3.5:4b"` first.

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\setup_offline_model.ps1
```

Then start `start_offline_assistant.ps1`, leave its PowerShell window open, and use the Content Studio preview. The prototype page must be served at `http://127.0.0.1:8766/` for its local connection to be accepted.
