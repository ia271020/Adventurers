const accountById = (id) => document.getElementById(id);
const ACCOUNT_API = "/api/account";
let signedInAccount = null;

function accountNotice(message, type = "info") {
  const box = accountById("accountNotice");
  box.textContent = message;
  box.className = "account-notice " + type;
  box.hidden = !message;
}

function showAccountMode(mode) {
  const login = mode === "login";
  const register = mode === "register";
  accountById("loginTab").classList.toggle("active", login);
  accountById("registerTab").classList.toggle("active", register);
  accountById("loginTab").setAttribute("aria-selected", String(login));
  accountById("registerTab").setAttribute("aria-selected", String(register));
  accountById("loginForm").hidden = !login;
  accountById("registerForm").hidden = !register;
  accountById("resendForm").hidden = true;
  accountNotice("");
}

function gateAccount(show) {
  accountById("accountGate").hidden = !show;
  accountById("appShell").inert = show;
  accountById("appShell").setAttribute("aria-hidden", String(show));
  accountById("chatLauncher").hidden = show;
  if (show) accountById("loginEmail").focus();
}

function safeAccountText(value) {
  return String(value).replace(/[&<>"']/g, (ch) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
}

async function accountRequest(path, options = {}) {
  const response = await fetch(ACCOUNT_API + path, {
    credentials: "same-origin",
    cache: "no-store",
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  let data;
  try { data = await response.json(); } catch (_) { data = {}; }
  if (!response.ok) throw new Error(data.error || "Account request could not be completed.");
  return data;
}

function showActivation(data) {
  const box = accountById("activationNotice");
  const link = accountById("activationLink");
  box.hidden = false;
  accountById("activationTitle").textContent = data.email_sent ? "Check your email" : "Activate this demo account";
  accountById("activationText").textContent = data.message || "Open the activation email, then return here to sign in.";
  if (data.demo_activation_url) {
    link.href = data.demo_activation_url;
    link.hidden = false;
    link.textContent = "Activate account on this computer";
  } else {
    link.removeAttribute("href");
    link.hidden = true;
  }
}

function applyAccount(user) {
  signedInAccount = user;
  window.KimuXAccountId = String(user.id);
  const name = user.name || user.email.split("@")[0];
  const initials = name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
  accountById("profileAvatar").textContent = initials || "U";
  accountById("profileName").textContent = name;
  accountById("profileRole").textContent = user.role.toUpperCase();
  accountById("profileButton").setAttribute("aria-label", `${name}, ${user.role} account menu`);
  accountById("adminNav").hidden = user.role !== "admin";
  window.updateSavedCount?.();
  gateAccount(false);
}

function showModalContent(title, kicker, content) {
  accountById("modalTitle").textContent = title;
  accountById("modalKicker").textContent = kicker;
  accountById("modalBody").innerHTML = content;
  accountById("modalBackdrop").hidden = false;
}

function openAccountMenu() {
  if (!signedInAccount) { gateAccount(true); return; }
  const user = signedInAccount;
  showModalContent("Your account", "LOCAL WORKSPACE", `
    <div class="account-summary"><span class="account-summary-avatar">${safeAccountText(accountById("profileAvatar").textContent)}</span><div><strong>${safeAccountText(user.name)}</strong><small>${safeAccountText(user.email)}</small></div><span class="account-role-badge">${safeAccountText(user.role)}</span></div>
    <p class="modal-copy">Your demo account and campaign activity are stored on this computer.</p>
    <button class="account-logout" id="accountLogout" type="button">Sign out</button>
  `);
  accountById("accountLogout").addEventListener("click", async () => {
    try { await accountRequest("/logout", { method: "POST", body: "{}" }); }
    catch (_) { /* Clear the local view even when the server has stopped. */ }
    signedInAccount = null;
    window.KimuXAccountId = null;
    accountById("profileName").textContent = "Guest";
    accountById("profileAvatar").textContent = "GU";
    accountById("profileRole").textContent = "SIGNED OUT";
    accountById("adminNav").hidden = true;
    window.updateSavedCount?.();
    accountById("modalBackdrop").hidden = true;
    accountNotice("You have signed out.", "success");
    gateAccount(true);
  });
}

async function openAdminAccounts() {
  accountById("modalTitle").textContent = "Account administration";
  accountById("modalKicker").textContent = "ADMIN ONLY · LOCAL DEMO";
  accountById("modalBody").innerHTML = '<p class="modal-copy">Loading local accounts…</p>';
  accountById("modalBackdrop").hidden = false;
  try {
    const result = await accountRequest("/users");
    const rows = result.users.map((user) => `
      <tr><td><strong>${safeAccountText(user.name)}</strong><small>${safeAccountText(user.email)}</small></td>
      <td><span class="account-state ${user.active ? "active" : "pending"}">${user.active ? "Active" : "Pending activation"}</span></td>
      <td><select aria-label="Role for ${safeAccountText(user.email)}" data-role-choice="${user.id}" ${user.active ? "" : "disabled"}><option value="user" ${user.role === "user" ? "selected" : ""}>User</option><option value="admin" ${user.role === "admin" ? "selected" : ""}>Admin</option></select></td>
      <td><button class="role-save-button" type="button" data-role-save="${user.id}" ${user.active ? "" : "disabled"}>Save</button></td></tr>`).join("");
    accountById("modalBody").innerHTML = `
      <p class="modal-copy">Public signups always start as users. Admins can grant or remove admin access for activated accounts here. The last active admin is protected.</p>
      <div class="account-table-wrap"><table class="account-table"><thead><tr><th>Account</th><th>Status</th><th>Role</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="4">No accounts yet.</td></tr>'}</tbody></table></div>
      <div class="admin-boundary">This is a local prototype. Before production, connect approved KimuX identity, recovery, audit and deployment services.</div>`;
    accountById("modalBody").querySelectorAll("[data-role-save]").forEach((button) => {
      button.addEventListener("click", async () => {
        const id = button.dataset.roleSave;
        const select = accountById("modalBody").querySelector(`[data-role-choice="${id}"]`);
        button.disabled = true;
        try {
          const result = await accountRequest("/role", { method: "PUT", body: JSON.stringify({ user_id: Number(id), role: select.value }) });
          showModalContent("Account administration", "ADMIN ONLY · LOCAL DEMO", '<div class="account-admin-feedback">' + safeAccountText(result.message) + '</div><button class="account-refresh" id="reloadAccounts" type="button">Return to account list</button>');
          accountById("reloadAccounts").addEventListener("click", openAdminAccounts);
        } catch (error) {
          button.disabled = false;
          accountNotice(error.message, "error");
          alert(error.message);
        }
      });
    });
  } catch (error) {
    accountById("modalBody").innerHTML = `<div class="account-admin-feedback error">${safeAccountText(error.message)}</div>`;
  }
}

accountById("loginTab").addEventListener("click", () => showAccountMode("login"));
accountById("registerTab").addEventListener("click", () => showAccountMode("register"));
accountById("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  accountNotice("Signing in…");
  try {
    const data = await accountRequest("/login", { method: "POST", body: JSON.stringify({ email: accountById("loginEmail").value, password: accountById("loginPassword").value }) });
    accountById("activationNotice").hidden = true;
    accountNotice("");
    applyAccount(data.user);
  } catch (error) { accountNotice(error.message, "error"); }
});

accountById("registerForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  accountNotice("Creating your user account…");
  try {
    const data = await accountRequest("/register", { method: "POST", body: JSON.stringify({ name: accountById("registerName").value, email: accountById("registerEmail").value, password: accountById("registerPassword").value }) });
    accountById("loginEmail").value = accountById("registerEmail").value.trim();
    accountById("registerPassword").value = "";
    showAccountMode("login");
    showActivation(data);
    accountNotice("Account created. Activate it before signing in.", "success");
  } catch (error) { accountNotice(error.message, "error"); }
});

accountById("resendToggle").addEventListener("click", () => {
  accountById("loginForm").hidden = true;
  accountById("registerForm").hidden = true;
  accountById("resendForm").hidden = false;
  accountById("resendEmail").value = accountById("loginEmail").value;
  accountNotice("");
});
accountById("backToLogin").addEventListener("click", () => showAccountMode("login"));
accountById("resendForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  accountNotice("Preparing an activation link…");
  try {
    const data = await accountRequest("/resend", { method: "POST", body: JSON.stringify({ email: accountById("resendEmail").value }) });
    showActivation(data);
    accountNotice(data.message, "success");
  } catch (error) { accountNotice(error.message, "error"); }
});

accountById("adminNav").addEventListener("click", () => {
  accountById("sidebar").classList.remove("open");
  accountById("appShell").classList.remove("menu-open");
  openAdminAccounts();
});

async function initializeAccountAccess() {
  gateAccount(true);
  showAccountMode("login");
  const activationToken = new URLSearchParams(window.location.search).get("activate");
  if (activationToken) {
    try {
      const result = await accountRequest("/activate?token=" + encodeURIComponent(activationToken));
      history.replaceState({}, "", window.location.pathname);
      accountNotice(result.message, "success");
    } catch (error) { accountNotice(error.message, "error"); }
  }
  try {
    const data = await accountRequest("/me");
    if (data.authenticated && data.user) applyAccount(data.user);
  } catch (_) {
    accountNotice("Start the account-enabled demo server with `python server.py` from the prototype folder.", "error");
  }
}

window.openAccountMenu = openAccountMenu;
window.addEventListener("DOMContentLoaded", initializeAccountAccess);
