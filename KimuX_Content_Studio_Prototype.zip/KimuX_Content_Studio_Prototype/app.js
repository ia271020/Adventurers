const byId = (id) => document.getElementById(id);
const LOCAL_ASSISTANT_API = "http://127.0.0.1:8767/api";
const CAMPAIGN_API = "/api/campaigns";
const samples = {
  coffee: { business:"Lakeview Coffee Co.",market:"Kampala, Uganda",exportMarket:"Dubai, UAE",product:"Single-origin Arabica",facts:"Ugandan Arabica; medium roast; 250 g pack; roasted weekly in small batches.",audience:"Coffee drinkers looking for locally sourced beans",exportAudience:"Coffee importers and distributors comparing Ugandan origin supply",channel:"Instagram",goal:"Product awareness",language:"English",tone:"Warm and confident",visualStyle:"Warm & organic",cta:"Explore the collection",hook:"A clear origin. A thoughtful roast.",directHook:"Meet a coffee with a clear origin.",warmHook:"Make room for a more thoughtful coffee moment.",captionTop:"ORIGIN",captionMain:"UGANDA" },
  auto: { business:"Northstar Auto",market:"Kampala, Uganda",exportMarket:"Kigali, Rwanda",product:"2021 Cityline compact SUV",facts:"2021 model; automatic transmission; 58,000 km; 2.0 L petrol engine.",audience:"Drivers comparing practical city vehicles",exportAudience:"Regional fleet buyers and vehicle resellers",channel:"Facebook",goal:"Get enquiries",language:"English",tone:"Clear and direct",visualStyle:"Clean & direct",cta:"Book a viewing",hook:"Your next drive starts with the right details.",directHook:"Explore a vehicle that fits your next drive.",warmHook:"A little more confidence for the road ahead.",captionTop:"READY FOR",captionMain:"THE ROAD" },
  fashion: { business:"Atelier Nia",market:"Kampala, Uganda",exportMarket:"Nairobi, Kenya",product:"Indigo wrap shirt",facts:"Cotton fabric; indigo blue; sizes S to XL; adjustable wrap tie.",audience:"Style-conscious shoppers looking for versatile pieces",exportAudience:"Boutiques seeking East African contemporary labels",channel:"Instagram",goal:"Product awareness",language:"English",tone:"Warm and confident",visualStyle:"Premium & minimal",cta:"Shop the new edit",hook:"Everyday style, made versatile.",directHook:"Discover a piece made for versatile styling.",warmHook:"A fresh favorite for the way you move.",captionTop:"STYLE",captionMain:"INDIGO EDIT" },
  design: { business:"Form & Field Studio",market:"Kampala and remote",exportMarket:"East Africa",product:"Brand identity starter package",facts:"Logo suite; color palette; and three editable social templates.",audience:"Small businesses preparing to launch or refresh",exportAudience:"Startups and SMEs preparing a brand launch",channel:"LinkedIn",goal:"Get enquiries",language:"English",tone:"Clear and direct",visualStyle:"Clean & direct",cta:"Book a discovery call",hook:"Make your brand easier to recognize.",directHook:"Build a clearer brand identity.",warmHook:"Give your next idea a visual home.",captionTop:"BRAND",captionMain:"IDENTITY" },
  food: { business:"Malaika Kitchen",market:"Kampala, Uganda",exportMarket:"Nairobi, Kenya",product:"Smoky groundnut stew",facts:"Groundnuts, tomatoes and greens; prepared fresh to order. Contains groundnuts.",audience:"Lunch seekers who enjoy local comfort food",exportAudience:"Cafe and food-service buyers sourcing local dishes",channel:"Instagram",goal:"Drive a purchase",language:"English",tone:"Energetic and friendly",visualStyle:"Bold & energetic",cta:"Order today's special",hook:"A familiar favorite, served fresh.",directHook:"Discover today's local kitchen special.",warmHook:"Bring a comforting favorite to the table.",captionTop:"FRESH FROM",captionMain:"THE KITCHEN" }
};
const marketerExamples = {
  coffee: { category:"COFFEE", pattern:"Origin → product detail → one clear action", text:"Ugandan Arabica, medium roast, roasted weekly in small batches. Explore the collection." },
  auto: { category:"AUTOMOTIVE", pattern:"Buyer need → verified specification → next step", text:"A 2021 compact SUV with automatic transmission and 58,000 km. Book a viewing." },
  fashion: { category:"FASHION", pattern:"Product appeal → material and size facts → action", text:"An indigo cotton wrap shirt, available in sizes S to XL. Shop the new edit." },
  design: { category:"DESIGN", pattern:"Customer outcome → named deliverables → conversation", text:"A starter identity package with a logo suite, color palette and three editable social templates. Book a discovery call." },
  food: { category:"FOOD", pattern:"Dish → ingredients or preparation → clear action + allergen", text:"Smoky groundnut stew with tomatoes and greens, prepared fresh to order. Contains groundnuts. Order today’s special." }
};
const creativePalettes = {
  "Warm & organic": { base:"#163b30", panel:"#205746", accent:"#e8bf68", text:"#fff8e8", soft:"#d3e6d9", pop:"#87d6a9" },
  "Clean & direct": { base:"#14293a", panel:"#1d4660", accent:"#39d7ad", text:"#f4f8fb", soft:"#c4d8e4", pop:"#73baff" },
  "Premium & minimal": { base:"#211e27", panel:"#39333f", accent:"#d6b878", text:"#f8f4eb", soft:"#d3cddd", pop:"#b29add" },
  "Bold & energetic": { base:"#351d30", panel:"#64364d", accent:"#ffc85d", text:"#fff5ed", soft:"#f1c5cb", pop:"#ff917a" }
};
const artwork = {
  coffee: '<svg viewBox="0 0 180 150" role="img" aria-label="Illustrative coffee pouch"><path class="object-base" d="M57 18h66l8 14-6 98H55l-6-98z"/><path class="object-line" d="M57 18l-8 14m74-14l8 14M57 31h66"/><circle class="object-accent" cx="90" cy="55" r="13"/><path d="M85 55h10m-5-5v10" stroke="#e4b55f" stroke-width="2"/><text x="90" y="84" text-anchor="middle" font-size="10" font-weight="800" fill="#0b302e">LAKEVIEW</text><text x="90" y="98" text-anchor="middle" font-size="12" font-weight="800" fill="#0b302e">COFFEE</text><text x="90" y="110" text-anchor="middle" font-size="6" letter-spacing="1" fill="#418a78">UGANDAN ARABICA</text></svg>',
  auto: '<svg viewBox="0 0 210 130" role="img" aria-label="Illustrative compact car"><path class="object-base" d="M35 76l14-27q5-10 16-10h68q12 0 20 10l18 27 11 7v21H28V83z"/><path class="object-line" d="M51 69h113M65 46l-13 22m76-22l19 22"/><path fill="#0b302e" d="M68 47h56v20H58zM131 47h5q9 0 15 8l8 12h-27z"/><circle class="object-accent" cx="62" cy="103" r="15"/><circle class="object-accent" cx="155" cy="103" r="15"/><circle fill="#e4b55f" cx="62" cy="103" r="6"/><circle fill="#e4b55f" cx="155" cy="103" r="6"/><path class="object-line" d="M38 82h13m127 0h12"/></svg>',
  fashion: '<svg viewBox="0 0 180 150" role="img" aria-label="Illustrative wrap shirt"><path class="object-base" d="M60 22L78 15h24l18 7 22 18-16 22-14-10v73H68V52L54 62 38 40z"/><path class="object-line" d="M78 15l12 17 12-17M90 32v40m0 0l21 17-21 7-21-7zM68 52l22 20 22-20"/><path fill="#0b302e" d="M77 15h26L90 34z"/><circle fill="#e4b55f" cx="91" cy="46" r="2"/><circle fill="#e4b55f" cx="91" cy="55" r="2"/></svg>',
  design: '<svg viewBox="0 0 180 150" role="img" aria-label="Illustrative design boards"><rect class="object-base" x="35" y="26" width="78" height="94" rx="8"/><rect fill="#d4aa5c" x="67" y="42" width="78" height="86" rx="8"/><path class="object-accent" d="M50 48h47v6H50zm0 14h31v4H50z"/><circle fill="#418a78" cx="62" cy="91" r="18"/><rect fill="#0b302e" x="83" y="82" width="19" height="18" rx="4"/><path d="M80 29h22" stroke="#0b302e" stroke-width="3" stroke-linecap="round"/><path d="M89 25v10" stroke="#0b302e" stroke-width="3" stroke-linecap="round"/></svg>',
  food: '<svg viewBox="0 0 180 150" role="img" aria-label="Illustrative serving bowl"><path d="M52 73h76l-8 39q-3 13-17 13H77q-14 0-17-13z" fill="#f4e8ca"/><path class="object-line" d="M45 72h90M57 80q5 32 17 42m49-42q-5 32-17 42"/><path d="M65 72q0-28 25-28t25 28" fill="#bd7552"/><path d="M75 65q-4-13 4-19m16 20q9-12 2-21" fill="none" stroke="#fff1d1" stroke-width="4" stroke-linecap="round"/><circle cx="78" cy="71" r="5" fill="#418a78"/><circle cx="104" cy="69" r="5" fill="#d9a851"/><path class="object-accent" d="M72 126h36"/></svg>'
};
let activeSample = "coffee";
let activeTrack = "local";
let selectedVariant = "balanced";
let reviewed = false;
let revisionNumber = 1;
let revisionHistory = [];
let toastTimer = null;
let activeCampaignId = null;
let currentQuality = null;
let currentOperation = "generate";
let isLoadingCampaign = false;
let latestReviewerNote = "";
let briefChangedSinceDraft = true;

function val(id) { return byId(id).value.trim(); }
function safeText(value) { return value.replace(/[<>]/g, "").trim(); }
function shortName(value) {
  const words = value.split(/\s+/).filter(Boolean);
  return words.slice(0, 3).map((word) => word.replace(/[^a-zA-Z0-9]/g, "")).join("");
}
function lowerFirst(value) {
  return value ? value.charAt(0).toLowerCase() + value.slice(1) : value;
}
function readBrief() {
  return {
    business: safeText(val("business")) || "Your business",
    market: safeText(val("market")) || "your market",
    product: safeText(val("product")) || "your product",
    facts: safeText(val("facts")),
    audience: safeText(val("audience")) || "your audience",
    exportAudience: safeText(val("exportAudience")) || "trade buyers",
    exportMarket: safeText(val("exportMarket")) || "your destination market",
    channel: val("channel"),
    goal: val("goal"),
    language: val("language"),
    tone: val("tone"),
    brand_guidance: safeText(val("brandGuidance")),
    visualStyle: val("visualStyle"),
    cta: safeText(val("cta")) || "Learn more",
    sample_type: activeSample,
    active_track: activeTrack
  };
}
function currentTarget(b) {
  return activeTrack === "export"
    ? { audience: b.exportAudience, market: b.exportMarket, channel: "LinkedIn" }
    : { audience: b.audience, market: b.market, channel: b.channel };
}
function updateSettingsSummary() {
  const language = val("language").split(" — ")[0];
  const channel = activeTrack === "export" ? "LinkedIn" : val("channel");
  byId("settingsSummary").textContent = [channel, val("goal"), language].filter(Boolean).join(" · ");
}
function setMenuOpen(open) {
  const desktop = window.matchMedia("(min-width: 951px)").matches;
  const drawerOpen = !desktop && open;
  const sidebarAvailable = desktop || drawerOpen;
  byId("appShell").classList.toggle("menu-open", drawerOpen);
  byId("menuToggle").setAttribute("aria-expanded", String(drawerOpen));
  byId("menuToggle").setAttribute("aria-label", drawerOpen ? "Close navigation" : "Open navigation");
  byId("navBackdrop").hidden = !drawerOpen;
  byId("sidebar").setAttribute("aria-hidden", String(!sidebarAvailable));
  byId("sidebar").toggleAttribute("inert", !sidebarAvailable);
}
function findUnsupportedClaim(text) {
  const risky = /\b(guaranteed|number one|#1|best in|certified organic|clinically proven|100% organic|fastest|free delivery|50% off|award[- ]winning|available(?: now)?|locally sourced|local sourcing|local coffee|local beans|sourced locally|delivered|delivery|fresh(?:ly)?|authentic|quality|taste|flavou?r|rich flavor|right here|made in|roasted in|from Kampala|world[- ]class)\b/i;
  const facts = val("facts").toLowerCase();
  const match = text.match(risky);
  return match && !facts.includes(match[0].toLowerCase()) ? match[0] : "";
}
function hasRiskyClaim(text) {
  return Boolean(findUnsupportedClaim(text));
}
function renderFactTrail() {
  const facts = safeText(val("facts")).split(/[;\n]+/).map((fact) => fact.replace(/[.\s]+$/, "").trim()).filter(Boolean);
  const container = byId("factTags");
  container.replaceChildren();
  if (!facts.length) {
    const empty = document.createElement("span"); empty.className = "fact-tag fact-tag-empty"; empty.textContent = "Add verified facts to the brief"; container.appendChild(empty);
    return;
  }
  facts.forEach((fact) => { const tag = document.createElement("span"); tag.className = "fact-tag"; tag.textContent = fact; container.appendChild(tag); });
}
function updateQuality() {
  const quality = currentQuality;
  const total = quality ? Number(quality.score) || 0 : null;
  byId("scoreValue").textContent = total === null ? "—" : String(total);
  byId("scoreRing").style.background = total === null ? "conic-gradient(#aab6ae 0deg 8deg, #e8eee8 8deg 360deg)" : "conic-gradient(var(--jade) 0deg " + Math.round(total * 3.6) + "deg, #e8eee8 " + Math.round(total * 3.6) + "deg 360deg)";
  const criteria = quality && Array.isArray(quality.criteria) ? quality.criteria : [];
  byId("criteriaList").innerHTML = criteria.map((item) => {
    const pct = Math.round((Number(item.score) || 0) / 5 * 100);
    return "<div class=\"criterion-block\"><div class=\"criterion\"><span class=\"criterion-label\">" + escapeHtml(item.label || item.key) + "</span><span class=\"criterion-track\"><span class=\"criterion-fill\" style=\"width:" + pct + "%\"></span></span><span class=\"criterion-value\">" + (Number(item.score) || 0) + "/5</span></div><small class=\"criterion-reason\">" + escapeHtml(item.reason || "No explanation returned.") + "</small></div>";
  }).join("");
  byId("scoreCopyTitle").textContent = quality ? "AI review complete" : "AI review needed";
  byId("scoreSubtext").textContent = quality ? quality.summary : "No score yet. Generate a draft and review it with the local model.";
  byId("qualityMethod").textContent = quality ? quality.method : "Six advisory criteria rated 0–5 by the local language model; total is normalized to 100. A marketer decides.";
  const feedback = byId("qualityFeedback");
  const flags = quality && Array.isArray(quality.claim_flags) ? quality.claim_flags : [];
  const improvements = quality && Array.isArray(quality.improvements) ? quality.improvements : [];
  feedback.classList.toggle("success", Boolean(quality));
  feedback.classList.toggle("error", false);
  if (!quality) {
    feedback.textContent = "Generate a draft, then run the review to see scores and specific reasons.";
  } else {
    feedback.innerHTML = "<strong>Review notes</strong>" +
      (flags.length ? "<p><b>Check these claims:</b> " + flags.map(escapeHtml).join(" · ") + "</p>" : "<p>No unsupported claim was flagged by the model. Verify all facts before use.</p>") +
      (improvements.length ? "<ul>" + improvements.map((item) => "<li>" + escapeHtml(item) + "</li>").join("") + "</ul>" : "");
  }
  const text = byId("headlineText").value + " " + byId("captionText").value;
  const risky = findUnsupportedClaim(text);
  const modelFlags = flags.length > 0;
  byId("claimCheck").classList.toggle("warn", Boolean(risky) || modelFlags);
  byId("claimCheck").querySelector("strong").textContent = risky ? "Rule alert: “" + risky + "”" : modelFlags ? "AI flagged claims for verification" : "No obvious unsupported claim flagged";
  byId("claimCheck").querySelector("small").textContent = risky ? "This phrase is not in the supplied facts. Substantiate or remove it." : "A clean check is not proof. A marketer must verify every detail.";
}
function resizeTextareas() {
  [byId("headlineText"), byId("captionText")].forEach((el) => {
    el.style.height = "auto";
    el.style.height = Math.max(el.scrollHeight, el.id === "captionText" ? 67 : 23) + "px";
  });
}
function renderRevisionLog(title, detail) {
  const log = byId("revisionLog");
  log.replaceChildren();
  const heading = document.createElement("strong"); heading.textContent = title; log.appendChild(heading);
  const body = document.createElement("span"); body.textContent = detail; log.appendChild(body);
  revisionHistory.slice(0, -1).slice(-2).reverse().forEach((item) => {
    const entry = document.createElement("div"); entry.className = "revision-entry";
    const version = document.createElement("strong"); version.textContent = "V" + item.version + " · " + item.label;
    const note = document.createElement("span"); note.textContent = "Feedback: “" + item.note + "”";
    const change = document.createElement("span"); change.textContent = "Hook: “" + item.before + "” → “" + item.after + "”";
    entry.append(version, note, change); log.appendChild(entry);
  });
}
function renderDraft(variant, showMessage) {
  selectedVariant = variant;
  const b = readBrief();
  const target = currentTarget(b);
  byId("previewBusiness").textContent = b.business;
  byId("previewHandle").textContent = "@" + (shortName(b.business).toLowerCase() || "yourbrand") + " · sponsored";
  byId("channelPreview").textContent = target.channel;
  byId("languagePreview").textContent = b.language.split(" — ")[0];
  updateSettingsSummary();
  byId("trackDescription").textContent = activeTrack === "export" ? "B2B buyer · " + target.market : "Local customer · " + target.market;
  document.querySelectorAll(".track-tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.track === activeTrack));
  renderFactTrail();
  renderCreative(activeSample);
  renderMarketerExample(activeSample);
  const caption = byId("captionText").value;
  byId("previewLength").textContent = caption ? "~ " + Math.max(1, Math.ceil(caption.split(/\s+/).length / 3)) + " sec read" : "AI copy appears here";
  document.querySelectorAll(".variant-tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.variant === variant));
  updateQuality();
  resizeTextareas();
  if (showMessage) showToast("Brief updated. Generate with local AI when ready.");
}
function escapeXml(value) {
  return String(value || "").replace(/[&<>\"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&apos;" }[char]));
}
function truncateVisual(value, limit) {
  const text = String(value || "").trim();
  return text.length > limit ? text.slice(0, limit - 1).trimEnd() + "…" : text;
}
function splitVisualLines(value, maxChars, maxLines) {
  const words = String(value || "").trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let current = "";
  for (let i = 0; i < words.length; i += 1) {
    const word = truncateVisual(words[i], maxChars);
    const next = current ? current + " " + word : word;
    if (next.length > maxChars && current) {
      lines.push(current);
      current = word;
      if (lines.length === maxLines - 1) {
        lines.push(truncateVisual([current].concat(words.slice(i + 1)).join(" "), maxChars));
        return lines;
      }
    } else {
      current = next;
    }
  }
  if (current) lines.push(current);
  return lines.slice(0, maxLines);
}
function renderCreative(kind) {
  const b = readBrief();
  const target = currentTarget(b);
  const palette = creativePalettes[b.visualStyle] || creativePalettes["Warm & organic"];
  const productLines = splitVisualLines(b.product, 27, 2);
  const firstFact = (b.facts.split(/[;\n]+/).map((fact) => fact.trim()).filter(Boolean)[0] || "Add a verified product detail").replace(/[.\s]+$/, "");
  const business = escapeXml(truncateVisual(b.business, 42));
  const productSvg = productLines.map((line, index) => `<text x="54" y="${144 + index * 48}" fill="${palette.text}" font-size="43" font-weight="750" font-family="Segoe UI,Arial,sans-serif">${escapeXml(line)}</text>`).join("");
  const factSvg = escapeXml(truncateVisual(firstFact, 78));
  const audienceSvg = escapeXml(truncateVisual("For " + target.audience + " · " + target.market, 82));
  const callToAction = escapeXml(truncateVisual(b.cta || "Learn more", 23));
  const monogram = escapeXml((b.product || "K").trim().charAt(0).toUpperCase());
  const mode = activeTrack === "export" ? "EXPORT BUYER" : "LOCAL CUSTOMER";
  const label = escapeXml(target.channel.toUpperCase() + " · " + mode + " · " + b.goal.toUpperCase());
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 340" preserveAspectRatio="none" role="img" aria-label="${escapeXml(b.business + " campaign graphic for " + b.product)}"><defs><linearGradient id="campaign-bg" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="${palette.base}"/><stop offset="1" stop-color="${palette.panel}"/></linearGradient></defs><rect width="1200" height="340" rx="18" fill="url(#campaign-bg)"/><path d="M820 0h380v340H930c-22-69-32-122-22-177 8-51-22-104-88-163Z" fill="${palette.accent}" opacity=".16"/><circle cx="1034" cy="160" r="104" fill="${palette.pop}" opacity=".16"/><circle cx="1034" cy="160" r="74" fill="none" stroke="${palette.accent}" stroke-width="2" opacity=".6"/><text x="54" y="51" fill="${palette.soft}" font-size="18" font-weight="700" letter-spacing="1.3" font-family="Segoe UI,Arial,sans-serif">${business}</text><rect x="54" y="68" width="${Math.min(390, Math.max(210, label.length * 8))}" height="27" rx="13" fill="#06110e" opacity=".58"/><text x="68" y="87" fill="${palette.accent}" font-size="12" font-weight="800" letter-spacing="1.1" font-family="Segoe UI,Arial,sans-serif">${label}</text>${productSvg}<text x="54" y="236" fill="${palette.soft}" font-size="18" font-weight="600" font-family="Segoe UI,Arial,sans-serif">${factSvg}</text><text x="54" y="264" fill="${palette.soft}" font-size="14" font-family="Segoe UI,Arial,sans-serif">${audienceSvg}</text><rect x="54" y="282" width="208" height="39" rx="11" fill="${palette.accent}"/><text x="72" y="307" fill="${palette.base}" font-size="15" font-weight="800" font-family="Segoe UI,Arial,sans-serif">${callToAction}</text><text x="1034" y="194" text-anchor="middle" fill="${palette.text}" font-size="116" font-weight="300" font-family="Segoe UI,Arial,sans-serif">${monogram}</text><text x="1034" y="286" text-anchor="middle" fill="${palette.soft}" font-size="13" font-weight="700" letter-spacing="1.5" font-family="Segoe UI,Arial,sans-serif">${escapeXml(b.visualStyle.toUpperCase())}</text></svg>`;
  byId("creativeVisual").dataset.kind = kind;
  byId("creativeVisual").dataset.mood = b.visualStyle;
  byId("creativeVisual").setAttribute("aria-label", "Brief-tailored vector design: " + b.business + ", " + b.product + ", " + target.channel + ".");
  byId("creativeObject").innerHTML = svg;
  byId("visualCaptionTop").textContent = b.business;
  byId("visualCaptionMain").textContent = b.product;
}
function renderMarketerExample(kind) {
  const example = marketerExamples[kind] || marketerExamples.coffee;
  byId("exampleCategory").textContent = example.category;
  byId("examplePattern").textContent = example.pattern;
  byId("expertExample").textContent = "“" + example.text + "”";
}
function loadSample(kind) {
  const profile = samples[kind];
  if (!profile) return;
  activeSample = kind;
  activeTrack = "local";
  activeCampaignId = null;
  currentQuality = null;
  currentOperation = "generate";
  latestReviewerNote = "";
  briefChangedSinceDraft = true;
  reviewed = false;
  ["business", "market", "product", "facts", "audience", "exportAudience", "exportMarket", "channel", "goal", "language", "tone", "visualStyle", "cta"].forEach((key) => { byId(key).value = profile[key]; });
  byId("brandGuidance").value = "";
  revisionNumber = 1;
  revisionHistory = [];
  byId("reviewNote").value = "";
  renderRevisionLog("V1 · Brief-based draft", "Waiting for marketer feedback.");
  document.querySelectorAll(".sample-business").forEach((button) => button.classList.toggle("active", button.dataset.sample === kind));
  byId("headlineText").value = "";
  byId("captionText").value = "";
  byId("hashtagText").value = "";
  byId("draftState").textContent = "Ready for local AI";
  renderDraft("balanced", false);
  showToast(profile.business + " sample loaded.");
}
function showToast(message) {
  const toast = byId("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2400);
}
function currentDraft() {
  return { headline: byId("headlineText").value.trim(), caption: byId("captionText").value.trim(), hashtags: byId("hashtagText").value.trim() };
}
function campaignBriefPayload() {
  const b = readBrief();
  const target = currentTarget(b);
  return { ...b, target_audience: target.audience, target_market: target.market, target_channel: target.channel };
}
async function requestCampaigns(id = "") {
  const response = await fetch(CAMPAIGN_API + (id ? "?id=" + encodeURIComponent(id) : ""), { credentials: "same-origin", cache: "no-store" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Campaign history is unavailable.");
  return data;
}
async function updateSavedCount() {
  try {
    const data = await requestCampaigns();
    const campaigns = data.campaigns || [];
    byId("savedCount").textContent = String(campaigns.length);
    byId("dashboardCampaignCount").textContent = String(campaigns.length);
    const versions = campaigns.flatMap((campaign) => campaign.versions || []);
    const reviewedScores = versions.map((version) => version.quality && Number(version.quality.score)).filter((score) => Number.isFinite(score));
    byId("dashboardVersionCount").textContent = String(versions.length);
    byId("dashboardQualityAverage").textContent = reviewedScores.length ? Math.round(reviewedScores.reduce((sum, score) => sum + score, 0) / reviewedScores.length) + "/100" : "—";
    byId("dashboardLatestCampaign").textContent = campaigns.length ? (campaigns[0].title || "Campaign saved") : "No saved campaign yet";
    byId("dashboardLatestTime").textContent = campaigns.length ? "Updated " + campaigns[0].updated_at : "Save a generated version to begin";
  } catch (_) {
    byId("savedCount").textContent = "0";
    byId("dashboardCampaignCount").textContent = "0";
    byId("dashboardVersionCount").textContent = "0";
    byId("dashboardQualityAverage").textContent = "—";
    byId("dashboardLatestCampaign").textContent = "No saved campaign yet";
    byId("dashboardLatestTime").textContent = "Sign in to view account history";
  }
}
function showModal(title, kicker, html) {
  byId("modalTitle").textContent = title;
  byId("modalKicker").textContent = kicker;
  byId("modalBody").innerHTML = html;
  byId("modalBackdrop").hidden = false;
}
function openBrandPlaybook() {
  const html = "<p class=\"modal-copy\">Proposed demonstration guidance inferred from KimuX’s public positioning and the supplied visual reference. It is not an approved brand kit.</p>" +
    "<div class=\"playbook-item\"><strong>Visual reference</strong><p>Near-black workspace, charcoal cards, bright teal actions, and restrained color accents. Confirm the official KimuX design tokens with stakeholders.</p></div>" +
    "<div class=\"playbook-item\"><strong>Marketer example pattern</strong><p>Hook → audience value → substantiated proof → one action. The sample library in this prototype is illustrative; populate it with examples curated by KimuX marketing experts.</p></div>" +
    "<div class=\"playbook-item\"><strong>Drafting guardrails</strong><p>Use a relevant audience and channel, support product statements with supplied facts, and avoid invented prices, discounts, certifications or results.</p></div>" +
    "<div class=\"playbook-item\"><strong>Human review</strong><p>Marketer feedback guides iterative critique. A person verifies claims and approves every draft before use.</p></div>";
  showModal("Brand playbook", "PROPOSED STARTING POINT", html);
}
async function openSavedDrafts() {
  showModal("Campaign history", "YOUR WORKSPACE", '<p class="modal-copy">Loading campaigns saved to your account on this computer…</p>');
  try {
    const data = await requestCampaigns();
    const campaigns = data.campaigns || [];
    if (!campaigns.length) {
      byId("modalBody").innerHTML = '<div class="empty-state"><strong>No saved campaigns yet</strong>Generate and save a draft to start your version history.</div>';
      byId("savedCount").textContent = "0";
      return;
    }
    byId("modalBody").innerHTML = '<p class="modal-copy">Campaigns and saved versions are stored in the local SQLite database for your signed-in account.</p>' + campaigns.map((campaign) => {
      const latest = campaign.versions && campaign.versions[0];
      const version = latest ? "V" + latest.version : "No saved version";
      const brief = latest && latest.brief || {};
      return '<div class="draft-list-item"><span class="draft-list-icon">▤</span><div><strong>' + escapeHtml(campaign.title || campaign.product || "Untitled campaign") + '</strong><small>' + escapeHtml(campaign.business || "") + ' · ' + escapeHtml(brief.target_channel || brief.channel || "") + ' · ' + version + '</small></div><button class="load-draft" type="button" data-campaign-open="' + campaign.id + '">Open</button><button class="load-draft history-button" type="button" data-campaign-history="' + campaign.id + '">' + (campaign.versions || []).length + ' versions</button></div>';
    }).join("");
    byId("savedCount").textContent = String(campaigns.length);
    byId("modalBody").querySelectorAll("[data-campaign-open]").forEach((button) => button.addEventListener("click", () => loadCampaignVersion(Number(button.dataset.campaignOpen))));
    byId("modalBody").querySelectorAll("[data-campaign-history]").forEach((button) => button.addEventListener("click", () => openCampaignHistory(Number(button.dataset.campaignHistory))));
  } catch (error) {
    byId("modalBody").innerHTML = '<div class="empty-state"><strong>Campaign history unavailable</strong>' + escapeHtml(error.message) + '</div>';
  }
}
async function openCampaignHistory(id) {
  try {
    const data = await requestCampaigns(id);
    const campaign = data.campaign;
    const versions = campaign.versions || [];
    byId("modalTitle").textContent = campaign.title || "Campaign versions";
    byId("modalKicker").textContent = "VERSION HISTORY · " + versions.length + " SAVED";
    byId("modalBody").innerHTML = '<p class="modal-copy">Each save keeps a campaign snapshot, including its brief and AI review.</p>' + versions.map((version) => '<div class="draft-list-item"><span class="draft-list-icon">V' + version.version + '</span><div><strong>' + escapeHtml(version.draft.headline || "Campaign draft") + '</strong><small>' + escapeHtml(version.operation || "generate") + ' · ' + escapeHtml(version.saved_at || "") + (version.reviewed ? " · Human reviewed" : "") + '</small></div><button class="load-draft" type="button" data-version-open="' + version.version + '">Open</button></div>').join("");
    byId("modalBody").querySelectorAll("[data-version-open]").forEach((button) => button.addEventListener("click", () => loadCampaignVersion(id, Number(button.dataset.versionOpen))));
  } catch (error) { showToast(error.message); }
}
async function loadCampaignVersion(id, versionNumber = null) {
  try {
    const data = await requestCampaigns(id);
    const campaign = data.campaign;
    const version = versionNumber ? campaign.versions.find((item) => item.version === versionNumber) : campaign.versions[0];
    if (!version) throw new Error("This campaign has no saved version.");
    isLoadingCampaign = true;
    const brief = version.brief || {};
    ["business", "market", "product", "facts", "audience", "exportAudience", "exportMarket", "channel", "goal", "language", "tone", "brand_guidance", "visualStyle", "cta"].forEach((key) => { if (brief[key] !== undefined) byId(key === "brand_guidance" ? "brandGuidance" : key).value = brief[key]; });
    activeSample = samples[brief.sample_type] ? brief.sample_type : "coffee";
    activeTrack = brief.active_track === "export" ? "export" : "local";
    document.querySelectorAll(".sample-business").forEach((item) => item.classList.toggle("active", item.dataset.sample === activeSample));
    activeCampaignId = campaign.id;
    briefChangedSinceDraft = false;
    currentOperation = version.operation || "generate";
    latestReviewerNote = version.reviewer_note || "";
    byId("headlineText").value = version.draft.headline || "";
    byId("captionText").value = version.draft.caption || "";
    byId("hashtagText").value = version.draft.hashtags || "";
    currentQuality = version.quality && version.quality.criteria ? version.quality : null;
    reviewed = Boolean(version.reviewed);
    byId("reviewButton").classList.toggle("reviewed", reviewed);
    byId("reviewButton").innerHTML = reviewed ? "<span>✓</span> Reviewed" : "<span>✓</span> Mark reviewed";
    revisionNumber = version.version;
    revisionHistory = campaign.versions.filter((item) => item.version < version.version).map((item) => ({ version: item.version, label: item.operation || "Saved pass", note: item.reviewer_note || "", before: item.draft.headline || "", after: "" }));
    byId("versionBadge").textContent = "V" + version.version + (reviewed ? " · HUMAN REVIEWED" : " · SAVED");
    byId("draftState").textContent = reviewed ? "Human reviewed · V" + version.version : "Loaded · V" + version.version;
    renderDraft("balanced", false);
    isLoadingCampaign = false;
    byId("modalBackdrop").hidden = true;
    showToast("Campaign version loaded from your account history.");
  } catch (error) { isLoadingCampaign = false; showToast(error.message); }
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[char]));
}
function copyDraft() {
  if (!reviewed) { showToast("Run the AI review and mark the draft reviewed before copying it."); return; }
  const all = byId("headlineText").value + "\n\n" + byId("captionText").value + "\n\n" + byId("hashtagText").value;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(all).then(() => showToast("Draft copied to clipboard.")).catch(() => showToast("Copy is unavailable in this browser."));
  } else {
    const area = document.createElement("textarea"); area.value = all; document.body.appendChild(area); area.select(); document.execCommand("copy"); area.remove(); showToast("Draft copied to clipboard.");
  }
}
function downloadDraft() {
  if (!reviewed) { showToast("Run the AI review and mark the draft reviewed before exporting it."); return; }
  const d = currentDraft();
  const b = campaignBriefPayload();
  const content = b.business + "\n" + b.product + "\n" + b.target_channel + " · " + b.language + "\n\n" + d.headline + "\n\n" + d.caption + "\n\n" + d.hashtags + "\n\nLocal showcase prototype — human review required.\n";
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a"); anchor.href = url; anchor.download = "kimux-content-draft.txt"; anchor.click();
  URL.revokeObjectURL(url);
  showToast("Text export downloaded.");
}
function downloadVisual() {
  const svg = byId("creativeObject").querySelector("svg");
  if (!svg) { showToast("Generate a design from the brief first."); return; }
  const source = new XMLSerializer().serializeToString(svg);
  const blob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  const filename = (val("business") + "-" + val("product")).replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase() || "kimux-content-design";
  anchor.href = url; anchor.download = filename + "-creative.svg"; anchor.click();
  URL.revokeObjectURL(url);
  showToast("Editable vector design downloaded.");
}

function addChatMessage(text, role) {
  const row = document.createElement("div");
  row.className = "chat-message " + (role === "user" ? "user-message" : "bot-message");
  if (role !== "user") {
    const avatar = document.createElement("span"); avatar.className = "chat-mini-avatar"; avatar.textContent = "K"; row.appendChild(avatar);
  }
  const bubble = document.createElement("p");
  if (role === "assistant") {
    const citationPattern = /\[Source:\s*([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g;
    let offset = 0;
    let match;
    while ((match = citationPattern.exec(text))) {
      bubble.appendChild(document.createTextNode(text.slice(offset, match.index)));
      const link = document.createElement("a");
      link.textContent = "Source: " + match[1];
      link.href = match[2];
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      bubble.appendChild(link);
      offset = citationPattern.lastIndex;
    }
    bubble.appendChild(document.createTextNode(text.slice(offset)));
  } else {
    bubble.textContent = text;
  }
  row.appendChild(bubble);
  byId("chatMessages").appendChild(row);
  byId("chatMessages").scrollTop = byId("chatMessages").scrollHeight;
  return row;
}
async function refreshOfflineAssistantStatus() {
  const status = byId("assistantStatus");
  const footnote = byId("assistantFootnote");
  try {
    const response = await fetch(LOCAL_ASSISTANT_API + "/health", { cache: "no-store" });
    const health = await response.json();
    if (health.database_available && health.ollama_running && health.model_available) {
      const chatModel = health.chat_model || health.model;
      status.textContent = "Offline AI · drafts " + health.model + " · guide " + chatModel;
      footnote.textContent = "Campaign copy and answers use local models and SQLite knowledge · no cloud AI calls";
      byId("aiDisclosure").textContent = "Local AI ready · drafts " + health.model + " · guide " + chatModel;
      byId("dashboardAIState").textContent = "Drafts + guide ready";
    } else if (!health.ollama_running) {
      status.textContent = "Local model is not running";
      footnote.textContent = "Start the offline assistant in PowerShell to enable business answers.";
      byId("aiDisclosure").textContent = "Start Ollama and the offline assistant to enable local AI generation and review";
      byId("dashboardAIState").textContent = "Start assistant";
    } else {
      status.textContent = "Local model needs setup";
      footnote.textContent = "Download the model once while online, then use it offline.";
      byId("aiDisclosure").textContent = "Download the local model once, then start the offline assistant";
      byId("dashboardAIState").textContent = "Model setup needed";
    }
  } catch (_) {
    status.textContent = "Local assistant server is stopped";
    footnote.textContent = "Start start_offline_assistant.ps1 in the prototype folder; no cloud AI is used.";
    byId("aiDisclosure").textContent = "Start the offline assistant to enable local AI generation and review";
    byId("dashboardAIState").textContent = "Assistant stopped";
  }
}

async function localAIRequest(action, payload) {
  const response = await fetch(LOCAL_ASSISTANT_API + "/" + action, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "The local model could not complete this request.");
  return data;
}
function setGenerationBusy(busy, label = "Generating with local AI…") {
  ["generateButton", "optimizeButton", "refineButton", "applyFeedback", "reviewAIButton"].forEach((id) => { byId(id).disabled = busy; });
  byId("generateLabel").textContent = busy ? label : "Generate with local AI";
  byId("draftState").textContent = busy ? label : (byId("captionText").value ? "Draft ready for review" : "Ready for local AI");
}
async function generateWithLocalAI(operation = "generate", style = "", feedback = "") {
  const b = campaignBriefPayload();
  if (!b.product.trim()) { showToast("Enter the product or service first."); byId("product").focus(); return; }
  if (!b.target_audience.trim()) { showToast("Enter the target audience first."); byId(activeTrack === "export" ? "exportAudience" : "audience").focus(); return; }
  if (!b.facts.trim()) { showToast("Add verified product facts before generating."); byId("facts").focus(); return; }
  const existingCopy = byId("existingCopy").value.trim();
  if (briefChangedSinceDraft && ["feedback", "variant"].includes(operation)) { showToast("The brief changed. Generate a fresh draft before refining it."); return; }
  if (operation === "optimise" && !existingCopy) { showToast("Paste the copy you want to improve."); byId("existingCopy").focus(); return; }
  if (["feedback", "variant"].includes(operation) && !byId("captionText").value.trim()) { showToast("Generate a draft before asking for a revision."); return; }
  const current = currentDraft();
  const before = current.headline;
  const hasPriorDraft = Boolean(current.caption);
  setGenerationBusy(true, operation === "optimise" ? "Improving copy…" : operation === "feedback" ? "Applying marketer feedback…" : "Generating with local AI…");
  byId("aiDisclosure").textContent = "The local model is writing from your brief and verified facts…";
  try {
    const result = await localAIRequest("generate", {
      business_id: activeSample,
      brief: b,
      operation,
      style,
      feedback,
      existing_copy: existingCopy,
      current_draft: current
    });
    byId("headlineText").value = result.draft.headline || "";
    byId("captionText").value = result.draft.caption || "";
    byId("hashtagText").value = result.draft.hashtags || "";
    currentOperation = operation;
    currentQuality = null;
    briefChangedSinceDraft = false;
    reviewed = false;
    byId("reviewButton").classList.remove("reviewed");
    byId("reviewButton").innerHTML = "<span>✓</span> Mark reviewed";
    byId("draftState").textContent = "Generated locally · " + result.model;
    byId("aiDisclosure").textContent = "Generated on this computer with " + result.model + " · human review required";
    revisionNumber = hasPriorDraft ? revisionNumber + 1 : 1;
    if (operation === "feedback") {
      revisionHistory.push({ version: revisionNumber, label: "AI feedback pass", note: feedback, before, after: result.draft.headline });
      latestReviewerNote = feedback;
      byId("versionBadge").textContent = "V" + revisionNumber + " · AI REVISED";
      renderRevisionLog("V" + revisionNumber + " · AI feedback pass", "Feedback: “" + feedback + "” · Revised by the local model. Human review is still required.");
      byId("reviewNote").value = "";
    } else {
      latestReviewerNote = "";
      byId("versionBadge").textContent = "V" + revisionNumber + " · AI DRAFT";
      renderRevisionLog("V" + revisionNumber + " · " + (operation === "optimise" ? "AI-optimised draft" : "AI-generated draft"), result.draft.notes || "Generated from the current brief; verify facts before use.");
    }
    renderDraft(style || "balanced", false);
    updateQuality();
    showToast(operation === "optimise" ? "Copy improved. Run the local AI review separately when ready." : operation === "feedback" ? "Feedback applied. Run the local AI review separately when ready." : "Draft ready. Run the local AI review separately when ready.");
  } catch (error) {
    byId("aiDisclosure").textContent = "Local AI unavailable · start Ollama and the offline assistant, then retry";
    byId("draftState").textContent = "Local AI unavailable";
    byId("qualityFeedback").textContent = error.message;
    byId("qualityFeedback").classList.add("error");
    showToast(error.message);
  } finally {
    setGenerationBusy(false);
    if (byId("aiDisclosure").textContent.startsWith("Local AI unavailable")) byId("draftState").textContent = "Local AI unavailable";
    resizeTextareas();
  }
}
async function runAIReview(quiet = false) {
  if (briefChangedSinceDraft) { if (!quiet) showToast("Generate a fresh draft for the updated brief before reviewing it."); return; }
  const draft = currentDraft();
  if (!draft.headline && !draft.caption) { if (!quiet) showToast("Generate or enter a draft first."); return; }
  byId("reviewAIButton").disabled = true;
  if (!quiet) byId("qualityFeedback").textContent = "The local model is scoring six criteria and checking claims…";
  try {
    const result = await localAIRequest("review", { business_id: activeSample, brief: campaignBriefPayload(), draft });
    currentQuality = result.quality;
    updateQuality();
    if (!quiet) showToast("AI advisory review complete. A marketer makes the final decision.");
  } catch (error) {
    byId("qualityFeedback").textContent = error.message;
    byId("qualityFeedback").classList.add("error");
    if (!quiet) showToast(error.message);
  } finally { byId("reviewAIButton").disabled = false; }
}
async function saveCurrentDraft() {
  const draft = currentDraft();
  if (briefChangedSinceDraft) { showToast("Generate a fresh draft for this brief before saving it."); return; }
  if (!draft.headline || !draft.caption) { showToast("Generate a campaign draft before saving."); return; }
  const button = byId("saveButton");
  button.disabled = true;
  try {
    const response = await fetch(CAMPAIGN_API, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ campaign_id: activeCampaignId, brief: campaignBriefPayload(), draft, quality: currentQuality || {}, operation: currentOperation, reviewer_note: latestReviewerNote, reviewed })
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || "Campaign could not be saved.");
    activeCampaignId = result.campaign_id;
    byId("versionBadge").textContent = "V" + result.version + (reviewed ? " · HUMAN REVIEWED" : " · SAVED");
    await updateSavedCount();
    showToast(result.message || "Campaign version saved.");
  } catch (error) { showToast(error.message); }
  finally { button.disabled = false; }
}

async function sendChatMessage(message) {
  const text = message.trim();
  if (!text) return;
  addChatMessage(text, "user");
  byId("chatInput").value = "";
  const pending = addChatMessage("Searching local business and market knowledge…", "bot");
  try {
    const brief = campaignBriefPayload();
    brief.current_draft = currentDraft();
    const targetMarket = brief.target_market;
    const response = await fetch(LOCAL_ASSISTANT_API + "/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ business_id: activeSample, message: text, brief, target_market: targetMarket })
    });
    const result = await response.json();
    pending.querySelector("p").textContent = result.answer || result.error || "The local assistant returned no answer.";
    refreshOfflineAssistantStatus();
  } catch (_) {
    pending.querySelector("p").textContent = "I can’t reach the local model yet. Start start_offline_assistant.ps1 from the prototype folder, then try again. No cloud service is used.";
    refreshOfflineAssistantStatus();
  }
}

byId("briefForm").addEventListener("submit", (event) => { event.preventDefault(); generateWithLocalAI("generate"); });
byId("optimizeButton").addEventListener("click", () => generateWithLocalAI("optimise"));
byId("reviewAIButton").addEventListener("click", () => runAIReview(false));
document.querySelectorAll(".sample-business").forEach((button) => button.addEventListener("click", () => loadSample(button.dataset.sample)));
document.querySelectorAll(".variant-tab").forEach((tab) => tab.addEventListener("click", () => generateWithLocalAI("variant", tab.dataset.variant)));
document.querySelectorAll(".track-tab").forEach((tab) => tab.addEventListener("click", () => {
  activeTrack = tab.dataset.track;
  activeCampaignId = null;
  currentQuality = null;
  reviewed = false;
  briefChangedSinceDraft = true;
  byId("headlineText").value = "";
  byId("captionText").value = "";
  byId("hashtagText").value = "";
  byId("draftState").textContent = "Audience changed · ready to generate";
  renderDraft(selectedVariant, false);
  showToast(activeTrack === "export" ? "B2B audience selected. Generate to adapt the message." : "Local audience selected. Generate to adapt the message.");
}));
byId("refineButton").addEventListener("click", () => {
  const mode = byId("refineMode").value;
  generateWithLocalAI("variant", mode);
});
byId("reviewButton").addEventListener("click", () => {
  if (!byId("captionText").value.trim()) { showToast("Generate a campaign draft before marking it reviewed."); return; }
  if (!currentQuality) { showToast("Run the AI quality review before marking this draft reviewed."); return; }
  reviewed = !reviewed;
  byId("reviewButton").classList.toggle("reviewed", reviewed);
  byId("reviewButton").innerHTML = reviewed ? "<span>✓</span> Reviewed" : "<span>✓</span> Mark reviewed";
  byId("draftState").textContent = reviewed ? "Human reviewed" : "Draft ready";
  showToast(reviewed ? "Marked reviewed in this prototype — not published." : "Review status cleared.");
});
byId("applyFeedback").addEventListener("click", () => {
  const note = safeText(val("reviewNote"));
  if (!note) { showToast("Add a marketer note to guide the next draft."); byId("reviewNote").focus(); return; }
  generateWithLocalAI("feedback", "", note);
});
byId("saveButton").addEventListener("click", saveCurrentDraft);
byId("copyButton").addEventListener("click", copyDraft);
byId("downloadButton").addEventListener("click", downloadDraft);
byId("downloadVisualButton").addEventListener("click", downloadVisual);
byId("brandNav").addEventListener("click", () => { setMenuOpen(false); openBrandPlaybook(); });
byId("createNav").addEventListener("click", () => { setMenuOpen(false); document.querySelectorAll(".nav-link").forEach((item) => item.classList.remove("active")); byId("createNav").classList.add("active"); byId("briefTitle").scrollIntoView({ behavior: "smooth", block: "start" }); });
byId("savedNav").addEventListener("click", () => { setMenuOpen(false); openSavedDrafts(); });
byId("overviewNav").addEventListener("click", () => {
  setMenuOpen(false);
  document.querySelectorAll(".nav-link").forEach((item) => item.classList.remove("active"));
  byId("overviewNav").classList.add("active");
  byId("workspaceOverview").scrollIntoView({ behavior: "smooth", block: "start" });
});
byId("overviewRefresh").addEventListener("click", () => { updateSavedCount(); refreshOfflineAssistantStatus(); });
byId("workspaceButton").addEventListener("click", () => showToast("Showcase workspace · local demo"));
byId("profileButton").addEventListener("click", () => window.openAccountMenu?.());
byId("closeModal").addEventListener("click", () => { byId("modalBackdrop").hidden = true; });
byId("modalBackdrop").addEventListener("click", (event) => { if (event.target === byId("modalBackdrop")) byId("modalBackdrop").hidden = true; });
function setChatOpen(open, returnFocus = false) {
  const widget = byId("chatWidget");
  const launcher = byId("chatLauncher");
  widget.hidden = !open;
  launcher.setAttribute("aria-expanded", String(open));
  launcher.setAttribute("aria-label", open ? "Minimize local Studio Guide" : "Open local Studio Guide");
  if (open) {
    byId("chatInput").focus();
    refreshOfflineAssistantStatus();
  } else if (returnFocus && !launcher.hidden) {
    launcher.focus();
  }
}
document.addEventListener("pointerdown", (event) => {
  const widget = byId("chatWidget");
  const launcher = byId("chatLauncher");
  if (!widget.hidden && !widget.contains(event.target) && !launcher.contains(event.target)) setChatOpen(false);
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    byId("modalBackdrop").hidden = true;
    setMenuOpen(false);
    if (!byId("chatWidget").hidden) setChatOpen(false, true);
  }
});
byId("menuToggle").addEventListener("click", () => setMenuOpen(byId("menuToggle").getAttribute("aria-expanded") !== "true"));
byId("navBackdrop").addEventListener("click", () => setMenuOpen(false));
byId("chatLauncher").addEventListener("click", () => setChatOpen(byId("chatWidget").hidden));
byId("chatClose").addEventListener("click", () => setChatOpen(false, true));
byId("chatForm").addEventListener("submit", (event) => { event.preventDefault(); sendChatMessage(byId("chatInput").value); });
document.querySelectorAll("[data-chat-prompt]").forEach((button) => button.addEventListener("click", () => sendChatMessage(button.dataset.chatPrompt)));
byId("exportAudience").value = samples.coffee.exportAudience;
byId("exportMarket").value = samples.coffee.exportMarket;
["business", "market", "product", "facts", "audience", "exportAudience", "exportMarket", "channel", "goal", "language", "tone", "brandGuidance", "visualStyle", "cta"].forEach((id) => {
  const updateBriefView = () => {
    if (!isLoadingCampaign) {
      activeCampaignId = null;
      currentQuality = null;
      reviewed = false;
      briefChangedSinceDraft = true;
      byId("reviewButton").classList.remove("reviewed");
      byId("reviewButton").innerHTML = "<span>✓</span> Mark reviewed";
      if (byId("captionText").value) byId("draftState").textContent = "Brief changed · generate a fresh draft";
    }
    const b = readBrief();
    byId("channelPreview").textContent = currentTarget(b).channel;
    byId("languagePreview").textContent = b.language.split(" — ")[0];
    renderFactTrail(); updateSettingsSummary(); updateQuality();
  };
  byId(id).addEventListener("input", updateBriefView);
  byId(id).addEventListener("change", updateBriefView);
});
byId("headlineText").value = "";
byId("captionText").value = "";
byId("hashtagText").value = "";
["headlineText", "captionText", "hashtagText"].forEach((id) => byId(id).addEventListener("input", () => {
  resizeTextareas(); currentQuality = null; reviewed = false; currentOperation = "manual edit";
  byId("reviewButton").classList.remove("reviewed");
  byId("reviewButton").innerHTML = "<span>✓</span> Mark reviewed";
  byId("draftState").textContent = "Edited · AI review needed";
  updateQuality();
}));
updateSavedCount();
setMenuOpen(false);
renderDraft("balanced", false);
byId("draftState").textContent = "Ready for local AI";
renderRevisionLog("Ready for a local AI draft", "Choose a sample or complete a campaign brief to get started.");
refreshOfflineAssistantStatus();
window.addEventListener("resize", () => setMenuOpen(false));
