"""Loopback-only web server and local account prototype for KimuX Content Studio."""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import os
import re
import secrets
import smtplib
import sqlite3
import sys
import time
from email.message import EmailMessage
from getpass import getpass
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit


ROOT = Path(__file__).resolve().parent
INSTANCE = Path(os.environ.get("KIMUX_ACCOUNT_DATA_DIR", ROOT / "instance"))
DATABASE = INSTANCE / "accounts.sqlite3"
HOST = "127.0.0.1"
PORT = int(os.environ.get("KIMUX_WEB_PORT", "8766"))
BASE_URL = os.environ.get("KIMUX_PUBLIC_BASE_URL", f"http://127.0.0.1:{PORT}").rstrip("/")
EMAIL_MODE = os.environ.get("KIMUX_EMAIL_MODE", "console").strip().lower()
PASSWORD_ITERATIONS = 310_000
MIN_PASSWORD_LENGTH = max(4, int(os.environ.get("KIMUX_MIN_PASSWORD_LENGTH", "4")))
ACTIVATION_TTL = 24 * 60 * 60
SESSION_TTL = 12 * 60 * 60
MAX_REQUEST_BYTES = 32_000
ALLOWED_ORIGINS = {f"http://127.0.0.1:{PORT}", f"http://localhost:{PORT}"}


def connect_db() -> sqlite3.Connection:
    INSTANCE.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DATABASE, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def initialize_db() -> None:
    with connect_db() as con:
        con.executescript(
            """
            CREATE TABLE IF NOT EXISTS accounts (
                account_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_salt TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('admin','user')),
                is_active INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                activated_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS activation_tokens (
                token_hash TEXT PRIMARY KEY,
                account_id INTEGER NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL,
                used_at INTEGER
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                account_id INTEGER NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS campaigns (
                campaign_id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER NOT NULL REFERENCES accounts(account_id) ON DELETE CASCADE,
                title TEXT NOT NULL,
                business TEXT NOT NULL,
                product TEXT NOT NULL,
                sample_type TEXT NOT NULL DEFAULT '',
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS campaign_versions (
                version_id INTEGER PRIMARY KEY AUTOINCREMENT,
                campaign_id INTEGER NOT NULL REFERENCES campaigns(campaign_id) ON DELETE CASCADE,
                version_number INTEGER NOT NULL,
                brief_json TEXT NOT NULL,
                headline TEXT NOT NULL,
                caption TEXT NOT NULL,
                hashtags TEXT NOT NULL DEFAULT '',
                operation TEXT NOT NULL DEFAULT 'generate',
                reviewer_note TEXT NOT NULL DEFAULT '',
                quality_json TEXT NOT NULL DEFAULT '{}',
                reviewed INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                UNIQUE(campaign_id, version_number)
            );
            CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
            CREATE INDEX IF NOT EXISTS idx_activation_account ON activation_tokens(account_id);
            CREATE INDEX IF NOT EXISTS idx_campaign_owner_updated ON campaigns(account_id, updated_at DESC);
            CREATE INDEX IF NOT EXISTS idx_campaign_versions_history ON campaign_versions(campaign_id, version_number DESC);
            """
        )
        con.execute("DELETE FROM sessions WHERE expires_at <= ?", (int(time.time()),))
        con.execute("DELETE FROM activation_tokens WHERE expires_at <= ? AND used_at IS NULL", (int(time.time()),))


def password_record(password: str, salt: bytes | None = None) -> tuple[str, str]:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PASSWORD_ITERATIONS)
    return salt.hex(), digest.hex()


def token_digest(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def normalize_email(value: str) -> str:
    return value.strip().casefold()


def valid_email(value: str) -> bool:
    return len(value) <= 254 and re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value) is not None


def activation_url(token: str) -> str:
    return f"{BASE_URL}/?activate={quote(token)}"


def send_activation_email(email: str, name: str, token: str) -> None:
    host = os.environ.get("KIMUX_SMTP_HOST", "").strip()
    sender = os.environ.get("KIMUX_SMTP_FROM", "").strip()
    if EMAIL_MODE != "smtp" or not host or not sender:
        raise RuntimeError("SMTP email is not configured")

    port = int(os.environ.get("KIMUX_SMTP_PORT", "587"))
    link = activation_url(token)
    message = EmailMessage()
    message["Subject"] = "Activate your KimuX Content Studio account"
    message["From"] = sender
    message["To"] = email
    message.set_content(
        f"Hello {name},\n\nActivate your KimuX Content Studio account using this link:\n{link}\n\n"
        "This link expires in 24 hours. If you did not request this account, you can ignore this message."
    )
    with smtplib.SMTP(host, port, timeout=15) as smtp:
        smtp.ehlo()
        if os.environ.get("KIMUX_SMTP_STARTTLS", "true").lower() not in {"0", "false", "no"}:
            smtp.starttls()
            smtp.ehlo()
        username = os.environ.get("KIMUX_SMTP_USERNAME", "")
        password = os.environ.get("KIMUX_SMTP_PASSWORD", "")
        if username:
            smtp.login(username, password)
        smtp.send_message(message)


def create_admin_interactive() -> int:
    initialize_db()
    with connect_db() as con:
        if con.execute("SELECT 1 FROM accounts WHERE role='admin' LIMIT 1").fetchone():
            print("An admin account already exists. Use its admin panel to grant another admin role.")
            return 1
    name = input("Admin display name: ").strip()
    email = normalize_email(input("Admin email: "))
    if not name or not valid_email(email):
        print("Enter a display name and a valid email address.")
        return 2
    password = getpass(f"Admin password (at least {MIN_PASSWORD_LENGTH} characters): ")
    confirm = getpass("Confirm password: ")
    if len(password) < MIN_PASSWORD_LENGTH or password != confirm:
        print(f"Passwords must match and contain at least {MIN_PASSWORD_LENGTH} characters.")
        return 2
    salt, digest = password_record(password)
    now = int(time.time())
    try:
        with connect_db() as con:
            con.execute(
                "INSERT INTO accounts(name,email,password_salt,password_hash,role,is_active,created_at,activated_at) "
                "VALUES(?,?,?,?, 'admin',1,?,?)",
                (name, email, salt, digest, now, now),
            )
    except sqlite3.IntegrityError:
        print("That email is already registered.")
        return 2
    print(f"Admin account created for {email}. Start the website with: python server.py")
    return 0


class KimuXHandler(SimpleHTTPRequestHandler):
    server_version = "KimuXLocal/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; connect-src 'self' http://127.0.0.1:8767; "
            "img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'",
        )
        super().end_headers()

    def send_json(self, status: int, payload: dict, extra_headers: dict[str, str] | None = None) -> None:
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        if extra_headers:
            for key, value in extra_headers.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Invalid request length") from exc
        if length <= 0 or length > MAX_REQUEST_BYTES:
            raise ValueError("Request is empty or too large")
        try:
            data = json.loads(self.rfile.read(length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("Send valid JSON") from exc
        if not isinstance(data, dict):
            raise ValueError("Send a JSON object")
        return data

    def check_same_origin(self) -> bool:
        origin = self.headers.get("Origin")
        if origin and origin.rstrip("/") not in ALLOWED_ORIGINS:
            self.send_json(403, {"error": "This local account service accepts same-origin requests only."})
            return False
        if not self.client_address[0].startswith("127."):
            self.send_json(403, {"error": "This prototype is available only on this computer."})
            return False
        return True

    def session_user(self) -> sqlite3.Row | None:
        from http.cookies import SimpleCookie

        cookies = SimpleCookie(self.headers.get("Cookie", ""))
        cookie = cookies.get("kimux_session")
        if not cookie:
            return None
        now = int(time.time())
        with connect_db() as con:
            return con.execute(
                "SELECT a.account_id,a.name,a.email,a.role,a.is_active FROM sessions s "
                "JOIN accounts a ON a.account_id=s.account_id "
                "WHERE s.token_hash=? AND s.expires_at>? AND a.is_active=1",
                (token_digest(cookie.value), now),
            ).fetchone()

    @staticmethod
    def public_user(user: sqlite3.Row) -> dict:
        return {"id": user["account_id"], "name": user["name"], "email": user["email"], "role": user["role"]}

    def require_user(self, admin: bool = False) -> sqlite3.Row | None:
        user = self.session_user()
        if not user:
            self.send_json(401, {"error": "Please sign in to continue."})
            return None
        if admin and user["role"] != "admin":
            self.send_json(403, {"error": "Administrator access is required."})
            return None
        return user

    @staticmethod
    def decode_campaign_version(row: sqlite3.Row) -> dict:
        try:
            brief = json.loads(row["brief_json"])
        except (TypeError, json.JSONDecodeError):
            brief = {}
        try:
            quality = json.loads(row["quality_json"])
        except (TypeError, json.JSONDecodeError):
            quality = {}
        return {
            "id": row["version_id"],
            "version": row["version_number"],
            "brief": brief,
            "draft": {"headline": row["headline"], "caption": row["caption"], "hashtags": row["hashtags"]},
            "operation": row["operation"],
            "reviewer_note": row["reviewer_note"],
            "quality": quality,
            "reviewed": bool(row["reviewed"]),
            "saved_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(row["created_at"])),
        }

    def campaign_record(self, campaign_id: int, account_id: int) -> dict | None:
        with connect_db() as con:
            campaign = con.execute(
                "SELECT campaign_id,title,business,product,sample_type,created_at,updated_at "
                "FROM campaigns WHERE campaign_id=? AND account_id=?",
                (campaign_id, account_id),
            ).fetchone()
            if not campaign:
                return None
            versions = con.execute(
                "SELECT * FROM campaign_versions WHERE campaign_id=? ORDER BY version_number DESC LIMIT 50",
                (campaign_id,),
            ).fetchall()
        return {
            "id": campaign["campaign_id"],
            "title": campaign["title"],
            "business": campaign["business"],
            "product": campaign["product"],
            "sample_type": campaign["sample_type"],
            "created_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(campaign["created_at"])),
            "updated_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(campaign["updated_at"])),
            "versions": [self.decode_campaign_version(row) for row in versions],
        }

    def do_GET(self) -> None:
        parsed = urlsplit(self.path)
        if parsed.path == "/api/account/health":
            self.send_json(200, {"available": True, "email_mode": EMAIL_MODE, "local_only": True})
            return
        if parsed.path == "/api/campaigns":
            user = self.require_user()
            if not user:
                return
            requested = parse_qs(parsed.query).get("id", [""])[0]
            if requested:
                try:
                    campaign = self.campaign_record(int(requested), user["account_id"])
                except ValueError:
                    self.send_json(400, {"error": "Choose a valid campaign."})
                    return
                if not campaign:
                    self.send_json(404, {"error": "Campaign not found."})
                    return
                self.send_json(200, {"campaign": campaign})
                return
            with connect_db() as con:
                rows = con.execute(
                    "SELECT campaign_id,title,business,product,updated_at FROM campaigns "
                    "WHERE account_id=? ORDER BY updated_at DESC LIMIT 100",
                    (user["account_id"],),
                ).fetchall()
            campaigns = []
            for row in rows:
                record = self.campaign_record(row["campaign_id"], user["account_id"])
                if record:
                    campaigns.append(record)
            self.send_json(200, {"campaigns": campaigns})
            return
        if parsed.path == "/api/account/activate":
            token = parse_qs(parsed.query).get("token", [""])[0]
            if not token:
                self.send_json(400, {"error": "Activation link is missing its token."})
                return
            with connect_db() as con:
                row = con.execute(
                    "SELECT account_id,expires_at,used_at FROM activation_tokens WHERE token_hash=?",
                    (token_digest(token),),
                ).fetchone()
                if not row or row["used_at"] or row["expires_at"] <= int(time.time()):
                    self.send_json(400, {"error": "This activation link is invalid, expired or already used."})
                    return
                now = int(time.time())
                con.execute("UPDATE activation_tokens SET used_at=? WHERE token_hash=?", (now, token_digest(token)))
                con.execute("UPDATE accounts SET is_active=1,activated_at=? WHERE account_id=?", (now, row["account_id"]))
            self.send_json(200, {"ok": True, "message": "Account activated. Sign in to continue."})
            return
        if parsed.path == "/api/account/me":
            user = self.session_user()
            if not user:
                self.send_json(200, {"authenticated": False})
            else:
                self.send_json(200, {"authenticated": True, "user": self.public_user(user)})
            return
        if parsed.path == "/api/account/users":
            user = self.require_user(admin=True)
            if not user:
                return
            with connect_db() as con:
                users = con.execute(
                    "SELECT account_id,name,email,role,is_active,created_at FROM accounts ORDER BY created_at DESC"
                ).fetchall()
            self.send_json(200, {"users": [
                {"id": row["account_id"], "name": row["name"], "email": row["email"],
                 "role": row["role"], "active": bool(row["is_active"]),
                 "created_at": time.strftime("%Y-%m-%d", time.localtime(row["created_at"]))}
                for row in users
            ]})
            return
        super().do_GET()

    def do_POST(self) -> None:
        if not self.check_same_origin():
            return
        path = urlsplit(self.path).path
        if path not in {"/api/account/register", "/api/account/login", "/api/account/logout", "/api/account/resend", "/api/campaigns"}:
            self.send_json(404, {"error": "Unknown account action."})
            return
        try:
            payload = self.read_json()
        except ValueError as exc:
            self.send_json(400, {"error": str(exc)})
            return
        if path == "/api/campaigns":
            self.save_campaign(payload)
        elif path == "/api/account/register":
            self.register(payload)
        elif path == "/api/account/login":
            self.login(payload)
        elif path == "/api/account/logout":
            self.logout()
        else:
            self.resend_activation(payload)

    def do_PUT(self) -> None:
        if not self.check_same_origin():
            return
        if urlsplit(self.path).path != "/api/account/role":
            self.send_json(404, {"error": "Unknown account action."})
            return
        admin = self.require_user(admin=True)
        if not admin:
            return
        try:
            payload = self.read_json()
            account_id = int(payload.get("user_id", 0))
            role = str(payload.get("role", ""))
        except (ValueError, TypeError) as exc:
            self.send_json(400, {"error": "Select a valid account and role."})
            return
        if role not in {"user", "admin"}:
            self.send_json(400, {"error": "Role must be user or admin."})
            return
        with connect_db() as con:
            target = con.execute("SELECT role,is_active FROM accounts WHERE account_id=?", (account_id,)).fetchone()
            if not target:
                self.send_json(404, {"error": "Account not found."})
                return
            if not target["is_active"]:
                self.send_json(400, {"error": "Activate the account before changing its role."})
                return
            if account_id == admin["account_id"] and role == "user":
                self.send_json(400, {"error": "Ask another administrator to change your own role."})
                return
            if target["role"] == "admin" and role == "user":
                admin_count = con.execute("SELECT COUNT(*) FROM accounts WHERE role='admin' AND is_active=1").fetchone()[0]
                if admin_count <= 1:
                    self.send_json(400, {"error": "The last active admin cannot be changed to a user."})
                    return
            con.execute("UPDATE accounts SET role=? WHERE account_id=?", (role, account_id))
        self.send_json(200, {"ok": True, "message": "Account role updated."})

    def register(self, payload: dict) -> None:
        name = str(payload.get("name", "")).strip()
        email = normalize_email(str(payload.get("email", "")))
        password = str(payload.get("password", ""))
        if not name or len(name) > 100:
            self.send_json(400, {"error": "Enter a name of 1 to 100 characters."})
            return
        if not valid_email(email):
            self.send_json(400, {"error": "Enter a valid email address."})
            return
        if len(password) < MIN_PASSWORD_LENGTH:
            self.send_json(400, {"error": f"Use a password with at least {MIN_PASSWORD_LENGTH} characters."})
            return
        salt, digest = password_record(password)
        now = int(time.time())
        token = secrets.token_urlsafe(32)
        try:
            with connect_db() as con:
                cursor = con.execute(
                    "INSERT INTO accounts(name,email,password_salt,password_hash,role,is_active,created_at) "
                    "VALUES(?,?,?,?, 'user',0,?)",
                    (name, email, salt, digest, now),
                )
                account_id = cursor.lastrowid
                con.execute(
                    "INSERT INTO activation_tokens(token_hash,account_id,expires_at) VALUES(?,?,?)",
                    (token_digest(token), account_id, now + ACTIVATION_TTL),
                )
        except sqlite3.IntegrityError:
            self.send_json(409, {"error": "An account already uses this email address."})
            return

        if EMAIL_MODE == "smtp":
            try:
                send_activation_email(email, name, token)
            except Exception as exc:
                print(f"Activation email failed for {email}: {type(exc).__name__}", file=sys.stderr)
                self.send_json(503, {"error": "Your account was created, but the activation email could not be sent. Ask the project admin to check email settings."})
                return
            self.send_json(201, {"ok": True, "email_sent": True, "message": "Activation email sent. Open it to verify the address, then sign in."})
            return

        link = activation_url(token)
        print(f"Demo activation link for {email}: {link}")
        self.send_json(201, {
            "ok": True, "email_sent": False, "demo_activation_url": link,
            "message": "Demo mode: no email provider is configured. Use the local activation link below.",
        })

    def resend_activation(self, payload: dict) -> None:
        email = normalize_email(str(payload.get("email", "")))
        if not valid_email(email):
            self.send_json(400, {"error": "Enter the email address used to create the account."})
            return
        with connect_db() as con:
            account = con.execute("SELECT account_id,name,is_active FROM accounts WHERE email=?", (email,)).fetchone()
            if not account:
                self.send_json(200, {"ok": True, "message": "If that pending account exists, a new activation message has been prepared."})
                return
            if account["is_active"]:
                self.send_json(200, {"ok": True, "message": "This account is already activated. You can sign in."})
                return
            con.execute("UPDATE activation_tokens SET used_at=? WHERE account_id=? AND used_at IS NULL", (int(time.time()), account["account_id"]))
            token = secrets.token_urlsafe(32)
            con.execute(
                "INSERT INTO activation_tokens(token_hash,account_id,expires_at) VALUES(?,?,?)",
                (token_digest(token), account["account_id"], int(time.time()) + ACTIVATION_TTL),
            )
        if EMAIL_MODE == "smtp":
            try:
                send_activation_email(email, account["name"], token)
            except Exception as exc:
                print(f"Activation email retry failed for {email}: {type(exc).__name__}", file=sys.stderr)
                self.send_json(503, {"error": "The activation email could not be sent. Ask the project admin to check email settings."})
                return
            self.send_json(200, {"ok": True, "email_sent": True, "message": "A new activation email has been sent."})
        else:
            link = activation_url(token)
            print(f"Demo activation link for {email}: {link}")
            self.send_json(200, {"ok": True, "email_sent": False, "demo_activation_url": link,
                                 "message": "Demo mode: use the new local activation link below."})

    def login(self, payload: dict) -> None:
        email = normalize_email(str(payload.get("email", "")))
        password = str(payload.get("password", ""))
        if not valid_email(email) or not password:
            self.send_json(400, {"error": "Enter your email and password."})
            return
        with connect_db() as con:
            row = con.execute("SELECT * FROM accounts WHERE email=?", (email,)).fetchone()
        if not row:
            password_record(password, b"\x00" * 16)
            self.send_json(401, {"error": "Email or password is incorrect."})
            return
        salt = bytes.fromhex(row["password_salt"])
        _, candidate = password_record(password, salt)
        if not hmac.compare_digest(candidate, row["password_hash"]):
            self.send_json(401, {"error": "Email or password is incorrect."})
            return
        if not row["is_active"]:
            self.send_json(403, {"error": "This account is not activated yet. Open the activation email or request a new demo link."})
            return
        token = secrets.token_urlsafe(32)
        now = int(time.time())
        with connect_db() as con:
            con.execute("INSERT INTO sessions(token_hash,account_id,expires_at,created_at) VALUES(?,?,?,?)",
                        (token_digest(token), row["account_id"], now + SESSION_TTL, now))
        cookie = f"kimux_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_TTL}"
        if BASE_URL.startswith("https://"):
            cookie += "; Secure"
        self.send_json(200, {"ok": True, "user": self.public_user(row)}, {"Set-Cookie": cookie})

    def logout(self) -> None:
        from http.cookies import SimpleCookie

        cookies = SimpleCookie(self.headers.get("Cookie", ""))
        cookie = cookies.get("kimux_session")
        if cookie:
            with connect_db() as con:
                con.execute("DELETE FROM sessions WHERE token_hash=?", (token_digest(cookie.value),))
        self.send_json(200, {"ok": True}, {"Set-Cookie": "kimux_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})

    def save_campaign(self, payload: dict) -> None:
        user = self.require_user()
        if not user:
            return
        brief = payload.get("brief") if isinstance(payload.get("brief"), dict) else None
        draft = payload.get("draft") if isinstance(payload.get("draft"), dict) else None
        if not brief or not draft:
            self.send_json(400, {"error": "A campaign brief and content draft are required."})
            return
        business = str(brief.get("business", "")).strip()[:160]
        product = str(brief.get("product", "")).strip()[:240]
        headline = str(draft.get("headline", "")).strip()[:500]
        caption = str(draft.get("caption", "")).strip()[:8000]
        hashtags = str(draft.get("hashtags", "")).strip()[:1000]
        if not business or not product or not headline or not caption:
            self.send_json(400, {"error": "Add the business, product, headline and caption before saving."})
            return
        try:
            campaign_id = int(payload.get("campaign_id") or 0)
        except (TypeError, ValueError):
            self.send_json(400, {"error": "Choose a valid campaign."})
            return
        operation = str(payload.get("operation", "generate"))[:32]
        reviewer_note = str(payload.get("reviewer_note", ""))[:1200]
        quality = payload.get("quality") if isinstance(payload.get("quality"), dict) else {}
        sample_type = str(brief.get("sample_type", ""))[:40]
        now = int(time.time())
        with connect_db() as con:
            if campaign_id:
                existing = con.execute(
                    "SELECT campaign_id FROM campaigns WHERE campaign_id=? AND account_id=?",
                    (campaign_id, user["account_id"]),
                ).fetchone()
                if not existing:
                    self.send_json(404, {"error": "Campaign not found in this account."})
                    return
                con.execute(
                    "UPDATE campaigns SET title=?,business=?,product=?,sample_type=?,updated_at=? WHERE campaign_id=? AND account_id=?",
                    (product, business, product, sample_type, now, campaign_id, user["account_id"]),
                )
            else:
                cursor = con.execute(
                    "INSERT INTO campaigns(account_id,title,business,product,sample_type,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                    (user["account_id"], product, business, product, sample_type, now, now),
                )
                campaign_id = int(cursor.lastrowid)
            version_number = con.execute(
                "SELECT COALESCE(MAX(version_number),0)+1 FROM campaign_versions WHERE campaign_id=?",
                (campaign_id,),
            ).fetchone()[0]
            con.execute(
                "INSERT INTO campaign_versions(campaign_id,version_number,brief_json,headline,caption,hashtags,operation,reviewer_note,quality_json,reviewed,created_at) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (campaign_id, version_number, json.dumps(brief, ensure_ascii=False), headline, caption, hashtags,
                 operation, reviewer_note, json.dumps(quality, ensure_ascii=False), int(bool(payload.get("reviewed"))), now),
            )
        self.send_json(201, {
            "ok": True,
            "campaign_id": campaign_id,
            "version": version_number,
            "saved_at": time.strftime("%Y-%m-%d %H:%M", time.localtime(now)),
            "message": f"Saved as version {version_number} in your campaign history.",
        })


def serve() -> None:
    initialize_db()
    try:
        server = ThreadingHTTPServer((HOST, PORT), KimuXHandler)
    except OSError as exc:
        raise SystemExit(f"Could not start on port {PORT}. Close any old preview server, then try again. ({exc})") from exc
    print(f"KimuX Content Studio with local accounts: http://127.0.0.1:{PORT}/")
    print("Bind: this computer only. New public signups start with the User role.")
    print(f"Email mode: {EMAIL_MODE}. Runtime account data: {DATABASE}")
    if EMAIL_MODE != "smtp":
        print("Demo activation links are shown in the browser and this terminal. No email is sent in console mode.")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nKimuX local server stopped.")
    finally:
        server.server_close()


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the local KimuX Content Studio account prototype.")
    parser.add_argument("--create-admin", action="store_true", help="Create the first local admin account securely.")
    args = parser.parse_args()
    if args.create_admin:
        return create_admin_interactive()
    serve()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
